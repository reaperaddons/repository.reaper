# -*- coding: utf-8 -*-
rrrerere = "101"
ii = "V1.1.0"
rRRr = "01/11/2016 22:00hrs GMT"
if 59 - 59: RrreRrr . RRreRRreRreRre * iiiIIii1IIi . iII111iiiii11 % I1IiiI
if 27 - 27: iIiiiI1IiI1I1 * IIiIiII11i * IiIIi1I1Iiii - RrrrererRrrerer
if 48 - 48: rRrer / RRrrRRr / I11i / Ii1I
if 48 - 48: iII111i % IiII + I1Ii111 / rrRrRrer * rrereRrerr
if 97 - 97: rRrerrerrRre - IIII / RRrrRRr - rRrerrerrRre
if 21 - 21: IiIIi1I1Iiii / iIiiiI1IiI1I1 % I1Ii111 / rRrer . IIII
if 100 - 100: I1IiiI
if 27 - 27: rrereRrerr * iII111iiiii11 + IiII * IIII - RrreRrr - rrRrRrer
if 30 - 30: iiiIIii1IIi * iiiIIii1IIi . iIiiiI1IiI1I1 - Ii1I
if 72 - 72: iIiiiI1IiI1I1 - rRrer
if 91 - 91: RrrrererRrrerer . RrreRrr / Ii1I % IiII / RrrrererRrrerer - RrreRrr
if 8 - 8: RRrrRRr * I11i * iiiIIii1IIi . rrereRrerr / rrereRrerr % rrereRrerr
if 22 - 22: I1Ii111 . rrereRrerr
if 41 - 41: rRrerrerrRre . IIII * rrereRrerr % RrreRrr
if 74 - 74: rrRrRrer * rrereRrerr
if 82 - 82: iiiIIii1IIi % rrereRrerr
if 86 - 86: rRrer % IIiIiII11i
if 80 - 80: iII111iiiii11 . IIiIiII11i
if 87 - 87: Ii1I / IIII + rRrerrerrRre - IIII . IIII / iIiiiI1IiI1I1
if 11 - 11: IIiIiII11i % RRrrRRr - IiIIi1I1Iiii
if 58 - 58: RrreRrr % rRrerrerrRre
if 54 - 54: iII111i % RRreRRreRreRre + IIiIiII11i - rrRrRrer / IiII
if 31 - 31: RrrrererRrrerer + iIiiiI1IiI1I1
if 13 - 13: iII111i * Ii1I * IIiIiII11i
import urllib , sys , xbmcplugin , xbmcgui , xbmcaddon , xbmc , os , json , base64
import re , urllib2 , datetime
import requests
import plugintools
import xbmcplugin , random , urlparse , urlresolver , liveresolver
from t0mm0 . common . addon import Addon
from metahandler import metahandlers
from addon . common . net import Net
from threading import Timer
if 55 - 55: iIiiiI1IiI1I1
if 43 - 43: rRrer - I1IiiI + rRrerrerrRre + I1Ii111
import time
if 17 - 17: RRrrRRr
rrererrrrRrerR = 'plugin.video.reaper'
Addon = xbmcaddon . Addon ( rrererrrrRrerR )
rRrRrrererRr = Addon . getLocalizedString
Rr = xbmcgui . Dialog ( )
rrereRrereRreRreR = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.143 Safari/537.36'
RrrRreRR = 'aHR0cDovL2xpdmVmb290YmFsbHZpZGVvLmNvbS8='
iiiIi = base64 . decodestring ( 'aHR0cDovL3Bhc3RlYmluLmNvbS9yYXcucGhwP2k9' )
IiIIIiI1I1 = 'http://reaperaddons.tk/'
RrRrerere = 'http://i.imgur.com/x7IbgCV.png'
IIiiIiI1 = 'http://i.imgur.com/x7IbgCV.png'
iiIiIIi = 'http://i.imgur.com/avF2XRX.png'
rrRrrreR = 'http://i.imgur.com/mn5hnDl.png'
RrrRre = 'http://i.imgur.com/Bd8pPFU.png'
II11iiii1Ii = 'http://i.imgur.com/Rnnd8g7.png'
RRrer = 'http://i.imgur.com/PX7Tdm7.png'
Rrr = 'http://i.imgur.com/ajZJyfj.png'
RrerreRr = 'http://i.imgur.com/BgEYv81.png'
RrrereRRRRR = 'http://i.imgur.com/DvsfHDb.png'
Rrr = 'http://i.imgur.com/ajZJyfj.png'
RreR = 'http://i.imgur.com/Pliz0yd.png'
RrererreRR = "<(.*?)>"
I11i1 = "[B][COLOR gold]INFORMATION[/COLOR][/B]"
if 25 - 25: IiIIi1I1Iiii - rrereRrerr . iII111iiiii11
I11ii1 = Net ( user_agent = 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.72 Safari/537.36' )
I11II1i = {
 'Accept' : 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'
 }
IIIII = Addon . getAddonInfo ( "name" )
rrrrrrRrerr = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
if 49 - 49: RRrrRRr * iiiIIii1IIi / I1IiiI / RrreRrr / RRrrRRr
I1i1I1II = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) ) . decode ( "utf-8" )
if 45 - 45: rRrerrerrRre . rRrer
if 83 - 83: Ii1I . iiiIIii1IIi . I11i
I1I = Addon . getAddonInfo ( 'icon' )
rRRrererRR = Addon . getAddonInfo ( 'path' ) . decode ( "utf-8" )
RrRr = os . path . join ( rRRrererRR , 'resources' , 'lib' )
sys . path . insert ( 0 , RrRr )
iI = os . path . getsize ( os . path . join ( rRRrererRR , 'default.py' ) )
rrereR = '' . join ( [ chr ( RRRreRRRrererr ) for RRRreRRRrererr in range ( 128 ) ] + [ ' ' ] * 128 )
Iii111II = xbmc . translatePath ( Addon . getAddonInfo ( 'profile' ) )
iiii11I = os . path . join ( Iii111II , 'cookies' )
RrrreRRrerRR = os . path . join ( iiii11I , "football.lwp" )
if os . path . exists ( iiii11I ) == False :
 os . makedirs ( iiii11I )
 I11ii1 . save_cookies ( RrrreRRrerRR )
 if 50 - 50: IIiIiII11i
import common
Ii1i11IIii1I = 'true'
RRRrRreRrer = 'http://www.filmon.com/'
RrerreRrr = 'http://www.filmon.com/api/init/'
if 56 - 56: IIII . rRrer * rrRrRrer . rRrer
RrererR = os . path . join ( xbmc . translatePath ( "special://userdata/addon_data" ) . decode ( "utf-8" ) , rrererrrrRrerR )
if not os . path . exists ( RrererR ) :
 os . makedirs ( RrererR )
 if 39 - 39: rrereRrerr - iIiiiI1IiI1I1 * RrrrererRrrerer % RRrrRRr * iIiiiI1IiI1I1 % iIiiiI1IiI1I1
print 'Reaper Addon ReaperAddonStartup#' + rrrerere + '-' + str ( iI ) + '  ' + str ( ii ) + '  ' + rRRr
RrRRRRR = 'NO DATA'
try :
 RrRRRRR = I11ii1 . http_GET ( 'http://pastebin.com/raw/aMVLHvqU' ) . content
except :
 pass
 if 33 - 33: I11i % I1IiiI
if RrRRRRR == 'NO DATA' :
 xbmcgui . Dialog ( ) . ok ( 'REAPER Server' , 'This unit is not receiving data from the Reaper server' , 'Test your connection speed' , 'Seek support if this continues' )
 print 'Reaper Addon no Compile Data * please check connection *'
else :
 print 'Reaper Addon read compile list successfully'
 if 78 - 78: IiII
RRrereRr = ''
RreRRRreRRrRreR = os . path . join ( RrRr , "childlock.txt" )
if not ( os . path . isfile ( RreRRRreRRrRreR ) ) :
 RRrereRr = 'OFF'
else :
 RRrereRr = 'ON'
 if 70 - 70: rrereRrerr * IiIIi1I1Iiii * IiII / I1Ii111
rR = os . path . join ( rRRrererRR , 'tempList.txt' )
RRrRreRrererre = os . path . join ( rRRrererRR , 'favorites.txt' )
if not ( os . path . isfile ( RRrRreRrererre ) ) :
 iII = open ( RRrRreRrererre , 'w' )
 iII . write ( '[]' )
 iII . close ( )
 if 80 - 80: rrereRrerr . Ii1I
def IIi ( ) :
 if 26 - 26: rrRrRrer
 RRR = plugintools . get_setting ( "auto_update" )
 if RRR == "true" :
  RrrerRRr = RrreRrRrererRRrer ( 'VERSIONDATE' )
  if RrrerRRr != rRRr :
   RRRrereR ( )
   if 84 - 84: Ii1I * RrrrererRrrerer / IiII - RRreRRreRreRre
 IiI1 ( "[COLOR gold][B]Build#" + rrrerere + "-" + str ( iI ) + "[/B][/COLOR]" , "Update" , 98 , rrRrrreR )
 RrreRrereRrrerre = RrereRrerRRrereRrere ( RrreRrRrererRRrer ( 'REAPERHOME' ) )
 if 11 - 11: rrereRrerr . I11i
 if RrreRrereRrrerre . find ( 'REAPERMENU' ) < 1 :
  print 'Reaper Addon cannot connect to the server'
  RrreRrereRrrerre = 'I:"0" A:"Cannot Connect" B:"[COLOR yellow][B]*SERVER DOWN*[/B][/COLOR]" C:"' + RrRrerere + '"'
  if 92 - 92: rrRrRrer . rRrerrerrRre
 IiI1 ( "[COLOR gold][B] UPDATE[/B][/COLOR]" , "Update" , 50 , "http://i.imgur.com/2IVcRS6.png" )
 i1i ( )
 iiI111I1iIiI = II ( RrreRrereRrrerre , 'I:' , '"#' )
 if 45 - 45: RRreRRreRreRre * RRrrRRr % IiIIi1I1Iiii * iII111iiiii11 + rrRrRrer . rRrer
 for RrrerrRrrer in iiI111I1iIiI :
  Ii1i1 = iiIii ( RrrerrRrrer , 'I:"' , '"' )
  rrrreR = iiIii ( RrrerrRrrer , 'A:"' , '"' )
  rRrRrerrereRRre = iiIii ( RrrerrRrrer , 'B:"' , '"' )
  I1I = iiIii ( RrrerrRrrer , 'C:"' , '"' )
  IiI1 ( '[COLOR white][B]' + rRrRrerrereRRre + '[/B][/COLOR]' , rrrreR , Ii1i1 , I1I )
 IiI1 ( '[COLOR white][B]MOVIES[/B][/COLOR]' , rrrreR , 760 , RreR )
 if 7 - 7: iII111i + rRrerrerrRre + RRreRRreRreRre
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 9 - 9: iIiiiI1IiI1I1 . RRrrRRr - IIII / RRrrRRr
 if 46 - 46: IiII . iII111i * IiII % I1IiiI
def iIIiII ( ) :
 ii1ii11IIIiiI = requests . get ( 'http://momomesh.tv/tvshows/' )
 ii1ii11IIIiiI = ii1ii11IIIiiI . content . replace ( '\n' , ' ' )
 RrereRRRrRrrreR = re . compile ( 'class="genres scrolling">(.+?)Release Year' , re . DOTALL ) . findall ( ii1ii11IIIiiI ) [ 0 ]
 RrerereRRrrererr = re . compile ( 'class="cat-item cat-item-.+?">(.+?)</li>' , re . DOTALL ) . findall ( RrereRRRrRrrreR )
 IiI1 ( '[COLOR red][B]SEARCH...[/B][/COLOR]' , 'url' , 763 , RrrereRRRRR , isFolder = True )
 for rrreRRr in RrerereRRrrererr :
  rrRRRrereRrr = re . compile ( '<a href="(.+?)" >(.+?)</a> <i>(.+?)</i>' ) . findall ( rrreRRr )
  for rrrreR , rRrRrerrereRRre , IiIIIi1iIi in rrRRRrereRrr :
   rrRRrrrrrr = '[COLOR gold]' + rRrRrerrereRRre + ' (' + str ( IiIIIi1iIi ) + ' Videos)[/COLOR]'
   rrRRrrrrrr = II1I ( rrRRrrrrrr )
   if not 'action-adventure' in rrrreR :
    IiI1 ( rrRRrrrrrr , rrrreR , 761 , RreR , isFolder = True )
    if 84 - 84: rrereRrerr . RrreRrr . rrereRrerr * I11i - IiII
def iiRrerrerRRRrRr ( title , url , iconimage ) :
 if 17 - 17: RRrrRRr . IIiIiII11i * rrRrRrer % rrRrRrer
 iI1I = I11I1II ( heading = "Please Enter a Search Term" )
 if ( not iI1I ) :
  Rr . ok ( AddonTitle , "Sorry, no search term was entered." )
  sys . exit ( 0 )
 RrrRrrrRr = iI1I
 if 46 - 46: rrRrRrer
 IiI1 ( '[COLOR red][I]You searched for ' + RrrRrrrRr + '[/I][/COLOR]' , 'url' , 1000 , RrrereRRRRR , isFolder = True )
 RRRreRRRrererr = 0
 ii1ii11IIIiiI = requests . get ( 'http://momomesh.tv/?s=' + str ( RrrRrrrRr ) )
 if 8 - 8: Ii1I * rRrer - I1Ii111 - RrrrererRrrerer * iII111i % IIiIiII11i
 iirRrrRRRrRr = [ ]
 i1Iii1i1I = [ ]
 RRrRrere = [ ]
 IiI111111IIII = [ ]
 i1Ii = [ ]
 if 14 - 14: rrRrRrer
 RrereRRRrRrrreR = re . compile ( '<article>(.+?)</article>' , re . DOTALL ) . findall ( ii1ii11IIIiiI . content )
 for rrreRRr in RrereRRRrRrrreR :
  if '<span class="movies">' in rrreRRr :
   rRrRrerrereRRre = re . compile ( '<a href=".+?">(.+?)</a></div><div class="meta">' ) . findall ( rrreRRr ) [ 0 ]
   url = re . compile ( '<a href="(.+?)">.+?</a></div><div class="meta">' ) . findall ( rrreRRr ) [ 0 ]
   try :
    I1I = re . compile ( '<img src="(.+?)" alt=".+?"/>' ) . findall ( rrreRRr ) [ 0 ]
   except : I1I = 'http://i.imgur.com/x7IbgCV.png'
   try :
    I1iI1iIi111i = re . compile ( '<span class="year">(.+?)</span>' ) . findall ( rrreRRr ) [ 0 ]
   except : I1iI1iIi111i = 'Unknown'
   try :
    iiIi1IIi1I = re . compile ( '<span class="rating">(.+?)</span' ) . findall ( rrreRRr ) [ 0 ]
   except : iiIi1IIi1I = '0'
   iiIi1IIi1I = iiIi1IIi1I . replace ( 'IMDb ' , '' )
   title = II1I ( rRrRrerrereRRre )
   IiI111111IIII . append ( str ( I1iI1iIi111i ) )
   iirRrrRRRrRr . append ( str ( title ) )
   i1Iii1i1I . append ( str ( url ) )
   RRrRrere . append ( str ( I1I ) )
   i1Ii . append ( str ( iiIi1IIi1I ) )
   rreRrRRrerererrRre = list ( zip ( IiI111111IIII , iirRrrRRRrRr , i1Iii1i1I , RRrRrere , i1Ii ) )
   RRRreRRRrererr = RRRreRRRrererr + 1
 IiI1 ( '[COLOR orange][I]We found ' + str ( RRRreRRRrererr ) + ' results.[/I][/COLOR]' , 'url' , 1000 , RrrereRRRRR , isFolder = True )
 IiI1 ( '[COLOR gold]-----------------------------------[/COLOR]' , 'url' , 1000 , IIiiIiI1 , isFolder = True )
 rrerrerrerRrerRR = sorted ( rreRrRRrerererrRre , key = lambda ii1Ii11I : int ( ii1Ii11I [ 0 ] ) , reverse = True )
 for I1iI1iIi111i , rRrRrerrereRRre , url , I1I , iiIi1IIi1I in rrerrerrerRrerRR :
  title = '[COLOR gold][B]' + rRrRrerrereRRre + ' [/B]-[/COLOR][COLOR orangered] ' + I1iI1iIi111i + ' (IMDb: ' + str ( iiIi1IIi1I ) + ')[/COLOR]'
  IiI1 ( title , url , 762 , I1I , isFolder = True )
  if 80 - 80: iIiiiI1IiI1I1
def RreRi1I1I ( title , url , iconimage ) :
 ii1ii11IIIiiI = requests . get ( url )
 iiI1I = url
 IiIiiIIiI = title
 iirRrrRRRrRr = [ ]
 i1Iii1i1I = [ ]
 RrereRRRrRrrreR = re . compile ( '{"file":"http(.+?)}' , re . DOTALL ) . findall ( ii1ii11IIIiiI . content )
 for rrreRRr in RrereRRRrRrrreR :
  rRrRrerrereRRre = re . compile ( 'type":".+?","label":"(.+?)"' ) . findall ( rrreRRr ) [ 0 ]
  RrrerrRrrer = rRrRrerrereRRre . replace ( 'p' , '' )
  url = re . compile ( '://(.+?)"' ) . findall ( rrreRRr ) [ 0 ]
  url = IiIiiIIiI + '^' + 'http://' + url + '|' + 'User-Agent=' + rrereRrereRreRreR + '&Referer=' + iiI1I
  iirRrrRRRrRr . append ( str ( RrrerrRrrer ) )
  i1Iii1i1I . append ( str ( url ) )
  rreRrRRrerererrRre = list ( zip ( iirRrrRRRrRr , i1Iii1i1I ) )
 rrerrerrerRrerRR = sorted ( rreRrRRrerererrRre , key = lambda ii1Ii11I : int ( ii1Ii11I [ 0 ] ) , reverse = True )
 for rRrRrerrereRRre , url in rrerrerrerRrerRR :
  IiI1 ( '[COLOR gold]' + rRrRrerrereRRre + 'p[/COLOR]' , url , 3 , iconimage , isFolder = False )
  if 67 - 67: IIII
def I1IIII1i ( title , url , iconimage ) :
 ii1ii11IIIiiI = requests . get ( url )
 ii1ii11IIIiiI = ii1ii11IIIiiI . content . replace ( '\n' , ' ' )
 try :
  I1I11i = re . compile ( '<div class="pagination"><span>.+? (.+?) .+?</span>' ) . findall ( ii1ii11IIIiiI ) [ 0 ]
  RrrerrRrrer = int ( I1I11i )
  Ii1I1I1i1Ii = RrrerrRrrer - 1
  i1 = RrrerrRrrer + 1
  I1I11i = str ( RrrerrRrrer )
  RrrerRrerer = str ( Ii1I1I1i1Ii )
  next = str ( i1 )
 except :
  I1I11i = 'UNKNOWN'
  RrrerRrerer = 'UNKNOWN'
  next = 'UNKNOWN'
  if 13 - 13: IiII * IiIIi1I1Iiii * IIII
 try :
  IiIIIi1iIi = re . compile ( '<div class="pagination"><span>.+? .+? of (.+?)</span>' ) . findall ( ii1ii11IIIiiI ) [ 0 ]
 except : IiIIIi1iIi = 'UNKNOWN'
 IiI1 ( '[COLOR red][B]PAGE ' + str ( I1I11i ) + ' OF ' + IiIIIi1iIi + '[/B][/COLOR]' , 'url' , 1000 , RrerreRr , isFolder = True )
 RrereRRRrRrrreR = re . compile ( '<article class="item.+?"(.+?)</article>' , re . DOTALL ) . findall ( ii1ii11IIIiiI )
 for rrreRRr in RrereRRRrRrrreR :
  rRrRrerrereRRre = re . compile ( '<a href=".+?"><img src=".+?" alt="(.+?)">' ) . findall ( rrreRRr ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"><img src=".+?" alt=".+?">' ) . findall ( rrreRRr ) [ 0 ]
  try :
   iI11iI1IiiIiI = re . compile ( '<span class="quality">(.+?)</span>' ) . findall ( rrreRRr ) [ 0 ]
  except : iI11iI1IiiIiI = 'Unknown'
  try :
   I1I = re . compile ( '<a href=".+?"><img src="(.+?)" alt=".+?">' ) . findall ( rrreRRr ) [ 0 ]
  except : I1I = IIiiIiI1
  try :
   I1iI1iIi111i = re . compile ( '<span>(.+?)</span></div>' ) . findall ( rrreRRr ) [ 0 ]
  except : I1iI1iIi111i = "UNKNOWN"
  title = '[COLOR gold][B]' + rRrRrerrereRRre + ' [/B]-[/COLOR][COLOR orangered] ' + I1iI1iIi111i + ' (' + str ( iI11iI1IiiIiI ) + ')[/COLOR]'
  title = II1I ( title )
  IiI1 ( title , url , 762 , I1I , isFolder = True )
  if 43 - 43: RrreRrr + IiIIi1I1Iiii * iIiiiI1IiI1I1 * rRrerrerrRre * RRreRRreRreRre
 try :
  url = re . compile ( 'rel="prev" href="(.+?)" />' ) . findall ( ii1ii11IIIiiI ) [ 0 ]
  IiI1 ( '[COLOR red][B]<-------- PREVIOUS PAGE (PAGE ' + str ( RrrerRrerer ) + ' OF ' + IiIIIi1iIi + ')[/B][/COLOR]' , url , 761 , I1I , isFolder = True )
 except : pass
 if 64 - 64: iII111i % iiiIIii1IIi * Ii1I
 try :
  url = re . compile ( 'rel="next" href="(.+?)" />' ) . findall ( ii1ii11IIIiiI ) [ 0 ]
  print url
  IiI1 ( '[COLOR red][B]--------> NEXT PAGE (PAGE ' + str ( next ) + ' OF ' + IiIIIi1iIi + ')[/B][/COLOR]' , url , 761 , Rrr , isFolder = True )
 except : pass
 if 79 - 79: RRreRRreRreRre
def rRRrereR ( ) :
 if 77 - 77: IiIIi1I1Iiii - I1IiiI - IiII . rRrer
 ii1ii11IIIiiI = requests . get ( 'http://momomesh.tv/movies' )
 if 39 - 39: iIiiiI1IiI1I1 / IIII + rRrerrerrRre / rRrer
 RrereRRRrRrrreR = re . compile ( '<ul class="genres scrolling">(.+?)Release Year' , re . DOTALL ) . findall ( ii1ii11IIIiiI . content )
 I1Ii11i = str ( RrereRRRrRrrreR )
 RrerereRRrrererr = re . compile ( '<li class="cat-item cat-item-.+?">(.+?)</li>' , re . DOTALL ) . findall ( I1Ii11i )
 IiI1 ( '[COLOR red][B]SEARCH...[/B][/COLOR]' , 'url' , 773 , RrrereRRRRR , isFolder = True )
 for rrreRRr in RrerereRRrrererr :
  rRrRrerrereRRre = re . compile ( '<a href=".+?">(.+?)</a> <i>.+?</i>' ) . findall ( rrreRRr ) [ 0 ]
  rrrreR = re . compile ( '<a href="(.+?)">.+?</a> <i>.+?</i>' ) . findall ( rrreRRr ) [ 0 ]
  IiIIIi1iIi = re . compile ( '<a href=".+?">.+?</a> <i>(.+?)</i>' ) . findall ( rrreRRr ) [ 0 ]
  rrRRrrrrrr = '[COLOR gold]' + rRrRrerrereRRre + ' (' + str ( IiIIIi1iIi ) + ' Videos)[/COLOR]'
  rrRRrrrrrr = II1I ( rrRRrrrrrr )
  IiI1 ( rrRRrrrrrr , rrrreR , 771 , RrrereRRRRR , isFolder = True )
  if 35 - 35: RRrrRRr
def RreRreRrrrrer ( title , url , iconimage ) :
 if 56 - 56: I11i % RRreRRreRreRre - IIiIiII11i
 iI1I = I11I1II ( heading = "Please Enter a Search Term" )
 if ( not iI1I ) :
  Rr . ok ( AddonTitle , "Sorry, no search term was entered." )
  sys . exit ( 0 )
 RrrRrrrRr = iI1I
 if 100 - 100: I1Ii111 - RRreRRreRreRre % Ii1I * iII111i + IIiIiII11i
 IiI1 ( '[COLOR red][I]You searched for ' + RrrRrrrRr + '[/I][/COLOR]' , 'url' , 1000 , IIiiIiI1 , isFolder = True )
 RRRreRRRrererr = 0
 ii1ii11IIIiiI = requests . get ( 'http://momomesh.tv/?s=' + str ( RrrRrrrRr ) )
 if 88 - 88: iII111iiiii11 - RrrrererRrrerer * RRreRRreRreRre * iII111iiiii11 . iII111iiiii11
 iirRrrRRRrRr = [ ]
 i1Iii1i1I = [ ]
 RRrRrere = [ ]
 IiI111111IIII = [ ]
 i1Ii = [ ]
 if 33 - 33: rRrerrerrRre + rrRrRrer * Ii1I / iiiIIii1IIi - IIiIiII11i
 RrereRRRrRrrreR = re . compile ( '<article>(.+?)</article>' , re . DOTALL ) . findall ( ii1ii11IIIiiI . content )
 for rrreRRr in RrereRRRrRrrreR :
  if '<span class="tvshows">' in rrreRRr :
   rRrRrerrereRRre = re . compile ( '<a href=".+?">(.+?)</a></div><div class="meta">' ) . findall ( rrreRRr ) [ 0 ]
   url = re . compile ( '<a href="(.+?)">.+?</a></div><div class="meta">' ) . findall ( rrreRRr ) [ 0 ]
   try :
    I1I = re . compile ( '<img src="(.+?)" alt=".+?"/>' ) . findall ( rrreRRr ) [ 0 ]
   except : I1I = 'http://i.imgur.com/x7IbgCV.png'
   try :
    I1iI1iIi111i = re . compile ( '<span class="year">(.+?)</span>' ) . findall ( rrreRRr ) [ 0 ]
   except : I1iI1iIi111i = 'Unknown'
   try :
    iiIi1IIi1I = re . compile ( '<span class="rating">(.+?)</span' ) . findall ( rrreRRr ) [ 0 ]
   except : iiIi1IIi1I = '0'
   iiIi1IIi1I = iiIi1IIi1I . replace ( 'IMDb ' , '' )
   title = II1I ( rRrRrerrereRRre )
   IiI111111IIII . append ( str ( I1iI1iIi111i ) )
   iirRrrRRRrRr . append ( str ( title ) )
   i1Iii1i1I . append ( str ( url ) )
   RRrRrere . append ( str ( I1I ) )
   i1Ii . append ( str ( iiIi1IIi1I ) )
   rreRrRRrerererrRre = list ( zip ( IiI111111IIII , iirRrrRRRrRr , i1Iii1i1I , RRrRrere , i1Ii ) )
   RRRreRRRrererr = RRRreRRRrererr + 1
 IiI1 ( '[COLOR orange][I]We found ' + str ( RRRreRRRrererr ) + ' results.[/I][/COLOR]' , 'url' , 1000 , IIiiIiI1 , isFolder = True )
 IiI1 ( '[COLOR gold]-----------------------------------[/COLOR]' , 'url' , 1000 , IIiiIiI1 , isFolder = True )
 rrerrerrerRrerRR = sorted ( rreRrRRrerererrRre , key = lambda ii1Ii11I : int ( ii1Ii11I [ 0 ] ) , reverse = True )
 for I1iI1iIi111i , rRrRrerrereRRre , url , I1I , iiIi1IIi1I in rrerrerrerRrerRR :
  title = '[COLOR gold][B]' + rRrRrerrereRRre + ' [/B]-[/COLOR][COLOR orangered] ' + I1iI1iIi111i + ' (IMDb: ' + str ( iiIi1IIi1I ) + ')[/COLOR]'
  IiI1 ( title , url , 772 , I1I , isFolder = True )
  if 54 - 54: rRrerrerrRre / iII111i . Ii1I % rrRrRrer
def RrRreRRRRrreR ( title , url , iconimage ) :
 if 81 - 81: RRreRRreRreRre / RrrrererRrrerer . I1IiiI + IIiIiII11i - IiII
 ii1ii11IIIiiI = requests . get ( url )
 iiI1I = url
 IiIiiIIiI = title
 if 74 - 74: iiiIIii1IIi * I11i + rRrer / I1IiiI / iIiiiI1IiI1I1 . IiIIi1I1Iiii
 iirRrrRRRrRr = [ ]
 i1Iii1i1I = [ ]
 if 62 - 62: iII111iiiii11 * IIiIiII11i
 RrereRRRrRrrreR = re . compile ( '{"file":"http(.+?)}' , re . DOTALL ) . findall ( ii1ii11IIIiiI . content )
 for rrreRRr in RrereRRRrRrrreR :
  rRrRrerrereRRre = re . compile ( 'type":".+?","label":"(.+?)"' ) . findall ( rrreRRr ) [ 0 ]
  RrrerrRrrer = rRrRrerrereRRre . replace ( 'p' , '' )
  url = re . compile ( '://(.+?)"' ) . findall ( rrreRRr ) [ 0 ]
  url = IiIiiIIiI + '^' + 'http://' + url + '|' + rrereRrereRreRreR + '&Referer=' + iiI1I
  iirRrrRRRrRr . append ( str ( RrrerrRrrer ) )
  i1Iii1i1I . append ( str ( url ) )
  rreRrRRrerererrRre = list ( zip ( iirRrrRRRrRr , i1Iii1i1I ) )
 rrerrerrerRrerRR = sorted ( rreRrRRrerererrRre , key = lambda ii1Ii11I : int ( ii1Ii11I [ 0 ] ) , reverse = True )
 for rRrRrerrereRRre , url in rrerrerrerRrerRR :
  IiI1 ( '[COLOR gold]' + rRrRrerrereRRre + 'p[/COLOR]' , url , 3 , iconimage , isFolder = False )
  if 58 - 58: rRrer % RRrrRRr
def i1RRrR ( title , url , iconimage ) :
 if 89 - 89: RRrrRRr + RrrrererRrrerer * IiII * I1Ii111
 ii1ii11IIIiiI = requests . get ( url )
 if 37 - 37: iII111iiiii11 - RRreRRreRreRre - RRrrRRr
 try :
  I1I11i = re . compile ( '<div class="pagination"><span>.+? (.+?) .+?</span>' ) . findall ( ii1ii11IIIiiI . content ) [ 0 ]
  RrrerrRrrer = int ( I1I11i )
  Ii1I1I1i1Ii = RrrerrRrrer - 1
  i1 = RrrerrRrrer + 1
  I1I11i = str ( RrrerrRrrer )
  RrrerRrerer = str ( Ii1I1I1i1Ii )
  next = str ( i1 )
 except :
  I1I11i = 'UNKNOWN'
  RrrerRrerer = 'UNKNOWN'
  next = 'UNKNOWN'
  if 77 - 77: iII111i * iiiIIii1IIi
 try :
  IiIIIi1iIi = re . compile ( '<div class="pagination"><span>.+? .+? of (.+?)</span>' ) . findall ( ii1ii11IIIiiI . content ) [ 0 ]
 except : IiIIIi1iIi = 'UNKNOWN'
 if 98 - 98: IIiIiII11i % I1Ii111 * iII111iiiii11
 IiI1 ( '[COLOR red][B]PAGE ' + str ( I1I11i ) + ' OF ' + IiIIIi1iIi + '[/B][/COLOR]' , 'url' , 1000 , IIiiIiI1 , isFolder = True )
 if 51 - 51: iiiIIii1IIi . rRrer / Ii1I + RRrrRRr
 RrereRRRrRrrreR = re . compile ( '<article class="item tvshows"(.+?)</article>' , re . DOTALL ) . findall ( ii1ii11IIIiiI . content )
 for rrreRRr in RrereRRRrRrrreR :
  rRrRrerrereRRre = re . compile ( '<a href=".+?"><img src=".+?" alt="(.+?)">' ) . findall ( rrreRRr ) [ 0 ]
  url = re . compile ( '<a href="(.+?)"><img src=".+?" alt=".+?">' ) . findall ( rrreRRr ) [ 0 ]
  try :
   iI11iI1IiiIiI = re . compile ( '<span class="quality">(.+?)</span>' ) . findall ( rrreRRr ) [ 0 ]
  except : iI11iI1IiiIiI = 'Unknown'
  try :
   I1I = re . compile ( '<a href=".+?"><img src="(.+?)" alt=".+?">' ) . findall ( rrreRRr ) [ 0 ]
  except : I1I = IIiiIiI1
  try :
   I1iI1iIi111i = re . compile ( '<span>(.+?)</span></div>' ) . findall ( rrreRRr ) [ 0 ]
  except : I1iI1iIi111i = "UNKNOWN"
  title = '[COLOR gold][B]' + rRrRrerrereRRre + ' [/B]-[/COLOR][COLOR orangered] ' + I1iI1iIi111i + ' (' + str ( iI11iI1IiiIiI ) + ')[/COLOR]'
  title = II1I ( title )
  IiI1 ( title , url , 772 , I1I , isFolder = True )
  if 33 - 33: IIII . iIiiiI1IiI1I1 % rrRrRrer + RRrrRRr
 try :
  url = re . compile ( '<link rel="prev" href="(.+?)"/>' ) . findall ( ii1ii11IIIiiI . content ) [ 0 ]
  IiI1 ( '[COLOR red][B]<-------- PREVIOUS PAGE (PAGE ' + str ( RrrerRrerer ) + ' OF ' + IiIIIi1iIi + ')[/B][/COLOR]' , url , 771 , I1I , isFolder = True )
 except : pass
 if 71 - 71: IiIIi1I1Iiii % iII111i
 try :
  url = re . compile ( '<link rel="next" href="(.+?)"/>' ) . findall ( ii1ii11IIIiiI . content ) [ 0 ]
  IiI1 ( '[COLOR red][B]--------> NEXT PAGE (PAGE ' + str ( next ) + ' OF ' + IiIIIi1iIi + ')[/B][/COLOR]' , url , 771 , Rrr , isFolder = True )
 except : pass
 if 98 - 98: IiII % RrreRrr % IIII + I1Ii111
def II1I ( text ) :
 if 78 - 78: I11i % Ii1I / rrRrRrer - iiiIIii1IIi
 text = str ( text )
 text = text . replace ( '\\r' , '' )
 text = text . replace ( '\\n' , '' )
 text = text . replace ( '\\t' , '' )
 text = text . replace ( '\\' , '' )
 text = text . replace ( '<br />' , '\n' )
 text = text . replace ( '<hr />' , '' )
 text = text . replace ( '&#039;' , "'" )
 text = text . replace ( '&#8217;' , "'" )
 text = text . replace ( '&quot;' , '"' )
 text = text . replace ( '&rsquo;' , "'" )
 text = text . replace ( '&amp;' , "&" )
 text = text . replace ( '&#038;' , "&" )
 text = text . replace ( '&#8211;' , "-" )
 if 69 - 69: rRrerrerrRre
 return text
 if 11 - 11: IIiIiII11i
def I1111i ( url ) :
 if 14 - 14: iII111i / RRrrRRr
 import requests
 if 32 - 32: IIiIiII11i * IiIIi1I1Iiii
 RreRrrRrrer = 0
 if 'http://vodlocker.123movies.online/?tv' in url :
  ii1ii11IIIiiI = requests . get ( url )
  if 29 - 29: IIiIiII11i % IIiIiII11i
  RrereRRRrRrrreR = re . compile ( '<div class="sort">(.+?)</div>' , re . DOTALL ) . findall ( ii1ii11IIIiiI . content )
  I1Ii11i = str ( RrereRRRrRrrreR )
  RrerereRRrrererr = re . compile ( '<li><a h(.+?)</li>' , re . DOTALL ) . findall ( I1Ii11i )
  for rrreRRr in RrerereRRrrererr :
   rRrRrerrereRRre = re . compile ( 'ref=".+?">(.+?)</a>' ) . findall ( rrreRRr ) [ 0 ]
   url = re . compile ( 'ref="(.+?)">.+?</a>' ) . findall ( rrreRRr ) [ 0 ]
   url = 'http://vodlocker.123movies.online' + url
   rrRRrrrrrr = '[COLOR gold]' + rRrRrerrereRRre + '[/COLOR]'
   IiI1 ( rrRRrrrrrr , url , 3 , I1I , isFolder = False )
   RreRrrRrrer = 1
   if 94 - 94: iiiIIii1IIi / IiIIi1I1Iiii % rrRrRrer * rrRrRrer * iIiiiI1IiI1I1
 if "movie" in str ( url ) :
  ii1ii11IIIiiI = requests . get ( url )
  if 29 - 29: RrrrererRrrerer + rRrer / RRrrRRr / iII111i * iiiIIii1IIi
  RrereRRRrRrrreR = re . compile ( '<span class="li-text">Genre</span>(.+?)<a href="#" title="Country">' , re . DOTALL ) . findall ( ii1ii11IIIiiI . content )
  I1Ii11i = str ( RrereRRRrRrrreR )
  RrerereRRrrererr = re . compile ( '<li>(.+?)</li>' , re . DOTALL ) . findall ( I1Ii11i )
  if 62 - 62: iII111i / Ii1I - RrrrererRrrerer . IiII
  for rrreRRr in RrerereRRrrererr :
   rRrRrerrereRRre = re . compile ( 'ref=".+?">(.+?)</a>' ) . findall ( rrreRRr ) [ 0 ]
   url = re . compile ( 'ref="(.+?)" title' ) . findall ( rrreRRr ) [ 0 ]
   rrRRrrrrrr = '[COLOR gold]' + rRrRrerrereRRre + '[/COLOR]'
   IiI1 ( rrRRrrrrrr , url , 770 , I1I , isFolder = True )
   RreRrrRrrer = 1
   if 11 - 11: I11i . RrrrererRrrerer * rrereRrerr * iII111iiiii11 + IIII
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 33 - 33: RRreRRreRreRre * RRrrRRr - rRrerrerrRre % rRrerrerrRre
def I11I ( name , url , iconimage ) :
 if 50 - 50: rRrerrerrRre * RrreRrr * iiiIIii1IIi - iIiiiI1IiI1I1 * RRrrRRr * rRrer
 ii1ii11IIIiiI = requests . get ( url )
 if 94 - 94: iII111iiiii11 + iII111iiiii11 . iIiiiI1IiI1I1 + IiII / I11i % I1Ii111
 RrereRRRrRrrreR = re . compile ( '<div class="movies-list movies-list-full">(.+?)<ul class="pagination"><li class="active">' , re . DOTALL ) . findall ( ii1ii11IIIiiI . content )
 I1Ii11i = str ( RrereRRRrRrrreR )
 RrerereRRrrererr = re . compile ( '-item">(.+?)<div class="ml' , re . DOTALL ) . findall ( I1Ii11i )
 for rrreRRr in RrerereRRrrererr :
  name = re . compile ( '<a href=".+?" class="ml-mask" title="(.+?)"' ) . findall ( rrreRRr ) [ 0 ]
  url = re . compile ( '<a href="(.+?)" class="ml-mask"' ) . findall ( rrreRRr ) [ 0 ]
  iconimage = re . compile ( 'data-original="(.+?)">' ) . findall ( rrreRRr ) [ 0 ]
  rrRRrrrrrr = '[COLOR gold]' + name + '[/COLOR]'
  if not "season" in name . lower ( ) :
   IiI1 ( rrRRrrrrrr , url , 780 , iconimage , isFolder = True )
   if 18 - 18: rrRrRrer * RRreRRreRreRre - iII111iiiii11 % IIiIiII11i . iIiiiI1IiI1I1 / I1IiiI
def RrerRre ( name , url , iconimage ) :
 if 7 - 7: IIiIiII11i
 ii1ii11IIIiiI = requests . get ( url )
 if 41 - 41: IiII * iiiIIii1IIi / iIiiiI1IiI1I1 * Ii1I
 RrereRRRrRrrreR = re . compile ( '<a class="mod-btn mod-btn-watch" href="(.+?)"' , re . DOTALL ) . findall ( ii1ii11IIIiiI . content )
 I1Ii11i = str ( RrereRRRrRrrreR )
 I1Ii11i = I1Ii11i . replace ( "['" , '' ) . replace ( "']" , '' )
 url = I1Ii11i
 ii1ii11IIIiiI = requests . get ( url )
 if 22 - 22: iII111iiiii11
def RRRRRr ( name , url , iconimage ) :
 if 25 - 25: RRreRRreRreRre * IiII + I11i . RRrrRRr . RRrrRRr
 ii1ii11IIIiiI = requests . get ( url )
 rRrrR = 0
 if 10 - 10: rRrer % rRrer - rRrer . rrRrRrer
 RrereRRRrRrrreR = re . compile ( '<head>(.+?)</html>' , re . DOTALL ) . findall ( ii1ii11IIIiiI . content )
 I1Ii11i = str ( RrereRRRrRrrreR )
 RrerereRRrrererr = re . compile ( '<a id="link-.+?"(.+?)<div id="links"' , re . DOTALL ) . findall ( I1Ii11i )
 for rrreRRr in RrerereRRrrererr :
  if 73 - 73: IiII % RrreRrr - IIiIiII11i
  if 7 - 7: RRreRRreRreRre * RrreRrr * I1Ii111 + IIII % RrrrererRrrerer - IIII
  rRrrR = rRrrR + 1
  rrRRrrrrrr = '[COLOR gold]Link ' + str ( rRrrR ) + '[/COLOR]'
  url = re . compile ( 'href="(.+?)">' ) . findall ( rrreRRr ) [ 0 ]
  url = "http://vodlocker.123movies.online" + url
  if 39 - 39: IiIIi1I1Iiii * iII111i % iII111i - iII111iiiii11 + RRrrRRr - IiII
  if 23 - 23: RrreRrr
  II1iIi11 = I11iiii ( url )
  IiI1 ( rrRRrrrrrr , II1iIi11 , 3 , I1I , isFolder = False )
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 60 - 60: IiII . I1IiiI + rrereRrerr / RRrrRRr . iIiiiI1IiI1I1
def I11iiii ( url ) :
 if 82 - 82: I11i / IIiIiII11i % iiiIIii1IIi / I1IiiI - IIiIiII11i
 ii1ii11IIIiiI = requests . get ( url )
 RrereRRRrRrrreR = re . compile ( '<a rel="nofollow" href="(.+?)"' , re . DOTALL ) . findall ( ii1ii11IIIiiI . content )
 url = "http://vodlocker.123movies.online/" + str ( RrereRRRrRrrreR )
 I1III1111iIi = str ( url )
 url = I1III1111iIi . replace ( 'player5' , 'player' ) . replace ( "['" , '' ) . replace ( "']" , '' ) . replace ( '["' , '' ) . replace ( '"]' , '' )
 if 38 - 38: rrRrRrer + IiII / rRrerrerrRre % IIII - I11i
 ii1ii11IIIiiI = requests . get ( url )
 if 14 - 14: Ii1I / rRrerrerrRre
 RrereRRRrRrrreR = re . compile ( 'href=".+?">http(.+?).html' , re . DOTALL ) . findall ( ii1ii11IIIiiI . content )
 RrrerrRrrer = str ( RrereRRRrRrrreR )
 RrrerrRrrer = RrrerrRrrer . replace ( 'embed-' , '' )
 try :
  Ii1I1I1i1Ii , i1 = RrrerrRrrer . split ( '-' )
  RrereRRRrRrrreR = str ( Ii1I1I1i1Ii )
 except :
  if 85 - 85: IiII
  if 20 - 20: Ii1I % rrereRrerr
  pass
 I1Ii11i = "http" + str ( RrereRRRrRrrreR )
 I1III1111iIi = str ( I1Ii11i )
 url = I1III1111iIi . replace ( "['" , '' ) . replace ( "']" , '' ) . replace ( '["' , '' ) . replace ( '"]' , '' ) . replace ( "</div>" , '' ) . replace ( "</span>" , '' ) . replace ( '<span>' , '' ) . replace ( '<div>' , '' ) . replace ( ' ' , '' )
 return url
 if 19 - 19: I11i % rrereRrerr + IIII / rRrerrerrRre . IIII
 if 12 - 12: I1IiiI + I1IiiI - I11i * IiIIi1I1Iiii % IiIIi1I1Iiii - iIiiiI1IiI1I1
def rreR ( ) :
 RRRrrr = RrrRreRRrreRRrrerreRreR ( )
 rre = 'http://www.vodlockerx.com/index.php?menu=search&query=' + RRRrrr
 RRrerrerRRRreR = RrereRrerRRrereRrere ( rre )
 i1i ( )
 if 49 - 49: I11i . RRrrRRr . iIiiiI1IiI1I1
 iiI111I1iIiI = II ( RRrerrerRRRreR , '<div class="span-6 inner-6 tt  view">' , '<div class="title-overflow"></div>' )
 for RrrerrRrrer in iiI111I1iIiI :
  rrerererrrrRrer = iiIii ( RrrerrRrrer , '<a href="http://www.vodlockerx.com/' , '" class="spec-border-ie" title="">' )
  rRrRrerrereRRre = rrerererrrrRrer . replace ( '-' , ' ' ) . upper ( ) . replace ( 'MOVIE/' , ' ' ) . upper ( )
  iI1i11 = iiIii ( RrrerrRrrer , 'src="' , '"' )
  rrerererrrrRrer = 'http://www.vodlockerx.com/' + rrerererrrrRrer
  rRrrR = rRrrR + 1
  IiI1 ( '[B][COLOR yellow]' + rRrRrerrereRRre + '[/COLOR][/B]' , rrerererrrrRrer , 240 , iI1i11 )
  if 66 - 66: RRreRRreRreRre % I11i + RrreRrr . rRrer / I1Ii111 + I11i
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 86 - 86: RRrrRRr
 if 5 - 5: rrereRrerr * rRrer
def i1Ii1i1I11Iii ( url ) :
 RRrerrerRRRreR = RrereRrerRRrereRrere ( url )
 I1i1i1 = ''
 if RRrerrerRRRreR . find ( 'rel="next' ) > 0 :
  I1i1i1 = iiIii ( RRrerrerRRRreR , '<link rel="next" href="//' , '"/>' )
  if 73 - 73: RRreRRreRreRre * rrRrRrer + I1Ii111 + IIII
 RRrerrerRRRreR = iiIii ( RRrerrerRRRreR , '<div class="nag cf">' , '<div class="loop-nav pag-nav">' )
 iiI111I1iIiI = II ( RRrerrerRRRreR , '<div id="post' , '<span class="overlay"></span>' )
 for RrrerrRrrer in iiI111I1iIiI :
  rrRRrrrrrr = iiIii ( RrrerrRrrer , ' title="' , '"' )
  rrerererrrrRrer = iiIii ( RrrerrRrrer , ' href="' , '"' )
  iI1i11 = "http://" + iiIii ( RrrerrRrrer , '<img src="//' , '" alt=' )
  IiI1 ( rrRRrrrrrr , rrerererrrrRrer , 15 , iI1i11 )
  if 40 - 40: iIiiiI1IiI1I1 . rRrer * rRrerrerrRre + iII111i + iII111i
 if len ( I1i1i1 ) > 0 :
  I1i1i1 = 'http://' + I1i1i1
  IiI1 ( '[B][COLOR yellow]Next Page >>>[/COLOR][/B]' , I1i1i1 , 9 , "http://i.imgur.com/ajZJyfj.png" )
  if 9 - 9: IiII % iII111iiiii11 . Ii1I % IiII
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 32 - 32: RrreRrr
def iiiII ( url ) :
 RRrerrerRRRreR = RrereRrerRRrereRrere ( url )
 iI1i11 = iiIii ( RRrerrerRRRreR , '<meta name="twitter:image:src" content="' , '"/>' )
 RRrerrerRRRreR = iiIii ( RRrerrerRRRreR , '<div class="entry-content rich-content">' , '<div id="extras">' )
 iiI111I1iIiI = II ( RRrerrerRRRreR , '<a class="small cool-blue vision-button"' , '</a>' )
 if 41 - 41: IiIIi1I1Iiii
 i1 = 0
 for RrrerrRrrer in iiI111I1iIiI :
  rrerererrrrRrer = iiIii ( RrrerrRrrer , 'button" href="' , '" target="' )
  if 'protect.cgi' not in rrerererrrrRrer :
   i1 = i1 + 1
   rrRRrrrrrr = "[COLOR gold] Source [" + str ( i1 ) + "] [/COLOR]" + iiIii ( RrrerrRrrer , 'blank">' , '</a>' )
   IiI1 ( rrRRrrrrrr , rrerererrrrRrer , 16 , iI1i11 )
   if 10 - 10: IiIIi1I1Iiii / IiIIi1I1Iiii / rRrerrerrRre . rRrerrerrRre
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 98 - 98: IiIIi1I1Iiii / IIiIiII11i . RRreRRreRreRre + RrrrererRrrerer
def iiIiii1iI1i ( name , url , thumb ) :
 I1ii1ii11i1I = name
 I1III1111iIi = url
 if 58 - 58: rrRrRrer + IiIIi1I1Iiii
 try :
  II1I1I1Ii = urllib2 . Request ( url )
  II1I1I1Ii . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
  RRRRrRrererreR = urlresolver . resolve ( urllib2 . urlopen ( II1I1I1Ii ) . url )
  I1I1I1IIi1III ( I1ii1ii11i1I , RRRRrRrererreR , thumb )
 except :
  II11IiiIII ( 'small' , 'REAPER Sorry Link Removed:' , 'Please try another one.' , 9000 )
  if 58 - 58: I1Ii111 + RRrrRRr - IIiIiII11i
def i1i ( ) :
 if 3 - 3: RrrrererRrrerer
 IiI1 ( I11i1 , 'akeZ51Sx' , 6 , "http://i.imgur.com/avF2XRX.png" , isFolder = True )
 if 97 - 97: rRrerrerrRre
def iiIII1i ( url ) :
 if 31 - 31: rrRrRrer . iII111i - IIII . iII111iiiii11 / iII111iiiii11
 xbmc . Player ( ) . play ( url )
 if 56 - 56: RrrrererRrrerer / Ii1I / RrreRrr + iII111iiiii11 - IiIIi1I1Iiii - IiII
def Iii1iiIi1II ( url ) :
 if 60 - 60: IIiIiII11i - Ii1I * IiII % iIiiiI1IiI1I1
 url = 'http://player.vimeo.com/video/' + url + '/config'
 try :
  RRrerrerRRRreR = RrereRrerRRrereRrere ( url )
  RRrerrerRRRreR = json . loads ( RRrerrerRRRreR )
  rrr = RRrerrerRRRreR [ 'request' ] [ 'files' ] [ 'h264' ]
  url = None
  try : url = rrr [ 'hd' ] [ 'url' ]
  except : pass
  try : url = rrr [ 'sd' ] [ 'url' ]
  except : pass
  IIiIiI1I = "PlayMedia(" + url + ")"
  xbmc . executebuiltin ( IIiIiI1I )
 except : pass
 if 100 - 100: iiiIIii1IIi + rRrer / IiIIi1I1Iiii . RrreRrr
 if 14 - 14: RRrrRRr * iII111i + rrRrRrer + RRreRRreRreRre + RrreRrr
def rRrRre ( url ) :
 if 77 - 77: iiiIIii1IIi . rrRrRrer % rrRrRrer + RrreRrr
 if urlresolver . HostedMediaFile ( url ) . valid_url ( ) : RrrererreRRreRrerer = urlresolver . HostedMediaFile ( url ) . resolve ( )
 elif liveresolver . isValid ( url ) == True : RrrererreRRreRrerer = liveresolver . resolve ( url )
 else : RrrererreRRreRrerer = url
 RreRrrr = xbmcgui . ListItem ( rRrRrerrereRRre , iconImage = 'DefaultVideo.png' , thumbnailImage = iI1i11 )
 RreRrrr . setPath ( RrrererreRRreRrerer )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , RreRrrr )
 if 21 - 21: IiIIi1I1Iiii
def I1ii1 ( url ) :
 RrreRrereRrrerre = 'I:"0" A:"Cannot Connect" B:"[COLOR yellow][B]*SERVER DOWN*[/B][/COLOR]" C:"' + RrRrerere + "'"
 Rrere = iiiIi
 if 92 - 92: iiiIIii1IIi * I1IiiI * rrRrRrer % iII111i % I11i + iIiiiI1IiI1I1
 RrreRrereRrrerre = RrereRrerRRrereRrere ( Rrere + url )
 i1iIi1I1i = "50"
 if 1 - 1: IiII % iII111i + RRreRRreRreRre + I1IiiI - RrrrererRrrerer
 iIIIII1ii1I = re . compile ( 'FORMAT"(.+?)"' ) . findall ( RrreRrereRrrerre )
 if iIIIII1ii1I :
  i1iIi1I1i = str ( iIIIII1ii1I )
  i1iIi1I1i = i1iIi1I1i . replace ( '[u\'' , '' ) . replace ( ']' , '' ) . replace ( '\'' , '' )
  if 13 - 13: RrreRrr + I1IiiI * iiiIIii1IIi % iII111iiiii11 - iIiiiI1IiI1I1 * iII111i
 if 'chin-info' not in url :
  i1i ( )
  if 26 - 26: iII111iiiii11 * IIiIiII11i + iII111i
 iiI111I1iIiI = II ( RrreRrereRrrerre , 'I:' , '"#' )
 for RrrerrRrrer in iiI111I1iIiI :
  Ii1i1 = iiIii ( RrrerrRrrer , 'I:"' , '"' )
  url = iiIii ( RrrerrRrrer , 'A:"' , '"' )
  rRrRrerrereRRre = iiIii ( RrrerrRrrer , 'B:"' , '"' )
  I1I = iiIii ( RrrerrRrrer , 'C:"' , '"' )
  if Ii1i1 == '60' or Ii1i1 == '3' or Ii1i1 == '61' :
   IiI1 ( '[COLOR white]' + rRrRrerrereRRre + '[/COLOR]' , url , Ii1i1 , I1I , isFolder = False )
  else :
   IiI1 ( '[COLOR white]' + rRrRrerrereRRre + '[/COLOR]' , url , Ii1i1 , I1I )
   if 24 - 24: RrreRrr % iiiIIii1IIi + iII111i / RrreRrr
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 70 - 70: RrrrererRrrerer * RRreRRreRreRre . IiII + IIiIiII11i . rrereRrerr
def Ii1iIiII1Ii ( url ) :
 RrreRrereRrrerre = '#A:-1,INVALID LIST \r\n http://youtube.com'
 Rrere = iiiIi
 if 42 - 42: RRreRRreRreRre * I1Ii111 . IiIIi1I1Iiii - IIiIiII11i * iiiIIii1IIi
 RrreRrereRrrerre = RrereRrerRRrereRrere ( Rrere + url )
 if 28 - 28: I11i
 i1iIi1I1i = "50"
 if 61 - 61: iII111i % iII111i * RRrrRRr / RRrrRRr
 iIIIII1ii1I = re . compile ( 'FORMAT"(.+?)"' ) . findall ( RrreRrereRrrerre )
 if iIIIII1ii1I :
  i1iIi1I1i = str ( iIIIII1ii1I )
  i1iIi1I1i = i1iIi1I1i . replace ( '[u\'' , '' ) . replace ( ']' , '' ) . replace ( '\'' , '' )
  if 75 - 75: rrereRrerr . IIII
 RrreRrereRrrerre = RrreRrereRrrerre . replace ( '#AAASTREAM:' , '#A:' ) . replace ( '#EXTINF:' , '#A:' )
 iII111iRrerererer = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( RrreRrereRrrerre )
 if 7 - 7: RRreRRreRreRre . I1Ii111
 for RRrerRRrr , rRrRrerrereRRre , url in iII111iRrerererer :
  rRRRrererrererer = RRrerRRrr
  if 9 - 9: Ii1I + IiII / IiII
  IiI1 ( rRrRrerrereRRre , url , 3 , RrRrerere , isFolder = False )
  if 12 - 12: iII111iiiii11 % RRrrRRr * IiII % iiiIIii1IIi / I1Ii111
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 27 - 27: RrreRrr % iIiiiI1IiI1I1 % IiII . RRreRRreRreRre - IiIIi1I1Iiii + rRrer
def rrRrer ( url ) :
 RrreRrereRrrerre = 'I:"0" A:"Cannot Connect" B:"[COLOR yellow][B]*SERVER DOWN*[/B][/COLOR]" C:"' + RrRrerere + "'"
 RrreRrereRrrerre = RrereRrerRRrereRrere ( iiiIi + url )
 if 51 - 51: rrereRrerr
 i1iIi1I1i = "50"
 if 25 - 25: iII111iiiii11 + rrereRrerr * I11i
 iIIIII1ii1I = re . compile ( 'FORMAT"(.+?)"' ) . findall ( RrreRrereRrrerre )
 if iIIIII1ii1I :
  i1iIi1I1i = str ( iIIIII1ii1I )
  i1iIi1I1i = i1iIi1I1i . replace ( '[u\'' , '' ) . replace ( ']' , '' ) . replace ( '\'' , '' )
  if 92 - 92: IIiIiII11i + IiII + RRreRRreRreRre / RRrrRRr + rRrerrerrRre
 i1i ( )
 if RRrereRr == 'OFF' :
  IiI1 ( '[COLOR green][B]ChildLock is OFF[/B][/COLOR] Click here to Activate' , "Childlock" , 400 , "http://i.imgur.com/k91F2Ql.png" , isFolder = False )
 else :
  IiI1 ( '[COLOR red][B]ChildLock is ON[/B][/COLOR] Click here to Deactivate' , "Childlock" , 400 , "http://i.imgur.com/k91F2Ql.png" , isFolder = False )
  if 18 - 18: IIII * rRrer . rrRrRrer / I11i / RrreRrr
 iiI111I1iIiI = II ( RrreRrereRrrerre , 'I:' , '"#' )
 for RrrerrRrrer in iiI111I1iIiI :
  Ii1i1 = iiIii ( RrrerrRrrer , 'I:"' , '"' )
  url = iiIii ( RrrerrRrrer , 'A:"' , '"' )
  rRrRrerrereRRre = iiIii ( RrrerrRrrer , 'B:"' , '"' )
  I1I = iiIii ( RrrerrRrrer , 'C:"' , '"' )
  if RRrereRr == 'OFF' :
   IiI1 ( '[COLOR lime]' + rRrRrerrereRRre + '[/COLOR]' , url , Ii1i1 , I1I )
   if 21 - 21: Ii1I / I11i + I1Ii111 + iII111iiiii11
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 91 - 91: RrreRrr / I1IiiI + rrRrRrer + IIII * RrreRrr
def RrRrRrrererre ( ) :
 if 90 - 90: IiIIi1I1Iiii % RRreRRreRreRre * iiiIIii1IIi . rrRrRrer
 I1iii11 = ''
 rrrreRiII1iii = 'Type Password to deactivate Childlock (case sensitive)'
 RreRRRreRRrRreR = os . path . join ( RrRr , "childlock.txt" )
 try :
  iII = open ( RreRRRreRRrRreR , 'r' )
  I1iii11 = iII . read ( )
  I1iii11 = iiIii ( I1iii11 , '{' , '}' )
  iII . close ( )
 except :
  I1iii11 = ""
  rrrreRiII1iii = 'Type Password to Activate Childlock (case sensitive)'
  if 12 - 12: iII111i
 Rre = ''
 iII1 = xbmc . Keyboard ( Rre , rrrreRiII1iii )
 iII1 . doModal ( )
 if iII1 . isConfirmed ( ) :
  Rre = iII1 . getText ( ) . replace ( ' ' , '+' )
  if Rre == None :
   return False
   if 27 - 27: RrrrererRrrerer . IiII + rRrer / iiiIIii1IIi % rrRrRrer . IIII
 if len ( Rre ) == 0 :
  xbmcgui . Dialog ( ) . ok ( 'REAPER Childlock' , 'No Password entered. No action taken' )
  return
 else :
  xbmcgui . Dialog ( ) . ok ( 'REAPER Childlock' , 'Password Entered: ' + Rre )
  if 14 - 14: Ii1I + I11i - rrRrRrer / RRreRRreRreRre . rRrerrerrRre
 if len ( Rre ) > 0 and I1iii11 == '' :
  try :
   iII = open ( RreRRRreRRrRreR , 'w' )
   iII . write ( '{' + Rre + '}' )
   iII . close ( )
   RRrereRr == 'ON'
   xbmcgui . Dialog ( ) . ok ( 'REAPER Childlock' , 'Childlock Activation Successful' , 'Return to REAPER Home Page' )
  except :
   RRrereRr == 'OFF'
   xbmcgui . Dialog ( ) . ok ( 'REAPER Childlock' , 'Childlock Activation Failed' , 'Exit Afterdark & Return' )
   if 45 - 45: rRrerrerrRre
 if len ( Rre ) > 0 and I1iii11 == Rre :
  try :
   os . remove ( RreRRRreRRrRreR )
   xbmcgui . Dialog ( ) . ok ( 'REAPER Childlock' , 'ChildLock removed' , 'Return to REAPER Home Page' )
  except :
   xbmcgui . Dialog ( ) . ok ( 'REAPER Childlock' , 'Cannot remove childlock' , 'Reboot and try again' )
   if 83 - 83: rRrer . iII111iiiii11
 if len ( Rre ) > 0 and I1iii11 <> Rre and len ( I1iii11 ) > 0 :
  xbmcgui . Dialog ( ) . ok ( 'REAPER Childlock' , 'Password incorrect Childlock still active' )
  if 58 - 58: RrreRrr + iII111iiiii11 % iII111iiiii11 / rrereRrerr / RrreRrr
def rRRrr ( url ) :
 if 14 - 14: RRrrRRr * Ii1I
 RreRRRreRRrrrrere = url
 I111iIi1 = RrereRrerRRrereRrere ( RrreRrRrererRRrer ( 'HAMSTER1' ) )
 I111iIi1 = rrrereRrererRrererer ( I111iIi1 )
 iI1i11 = ''
 if 71 - 71: I11i - IIII / rRrer * rRrer / I1IiiI . I1IiiI
 import requests
 Rr = xbmcgui . Dialog ( )
 ii1ii11IIIiiI = requests . get ( url )
 if 53 - 53: rRrerrerrRre
 i11iiI1111 = re . compile ( '<link rel="next" href="(.+?)">' , re . DOTALL ) . findall ( ii1ii11IIIiiI . content )
 rRrrrrrerereRrrere = str ( i11iiI1111 )
 rRrrrrrerereRrrere = rRrrrrrerereRrrere . replace ( '[' , '' ) . replace ( ']' , '' ) . replace ( "'" , '' ) . replace ( '"' , '' )
 IiI1 ( "[B][COLOR red]Next Page[/B][/COLOR]" , rRrrrrrerereRrrere , 600 , Rrr , isFolder = True )
 if 93 - 93: I11i / IIiIiII11i / iiiIIii1IIi % rRrerrerrRre % rRrerrerrRre
 RrereRRRrRrrreR = re . compile ( '<div class="video">(.+?)</div>' , re . DOTALL ) . findall ( ii1ii11IIIiiI . content )
 for rrreRRr in RrereRRRrRrrreR :
  rrerererrrrRrer = re . compile ( '<a href="(.+?)"' ) . findall ( rrreRRr ) [ 0 ]
  rRrRrerrereRRre = re . compile ( '<u>(.+?)</u>' ) . findall ( rrreRRr ) [ 0 ]
  try :
   IiI11iI1i1i1i = re . compile ( "<img src='(.+?)'" ) . findall ( rrreRRr ) [ 0 ]
  except : pass
  if 89 - 89: IiII
  url = rrerererrrrRrer
  rrRRrrrrrr = '[COLOR gold]' + rRrRrerrereRRre + '[/COLOR]'
  rrRRrrrrrr = rrRRrrrrrr . replace ( '&#039;' , "'" )
  IiI1 ( rrRRrrrrrr , url , 750 , IiI11iI1i1i1i , isFolder = False )
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 64 - 64: iIiiiI1IiI1I1 + RRreRRreRreRre / iiiIIii1IIi / IiIIi1I1Iiii . IIII % rrereRrerr
def iiI1I1ii ( name , url , iconimage ) :
 if 85 - 85: IIII / RRreRRreRreRre
 url = iI1iIIIi1i ( url )
 RreRrrr = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 xbmc . Player ( ) . play ( url , RreRrrr , False )
 if 89 - 89: iiiIIii1IIi
def i11iiiiI1i ( name , url , mode , iconimage , fanart , description = '' ) :
 rrr = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&iconimage=" + urllib . quote_plus ( iconimage )
 iIIii = True
 RreRrrr = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 RreRrrr . setProperty ( 'fanart_image' , fanart )
 iIIii = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = rrr , listitem = RreRrrr , isFolder = False )
 return iIIii
 if 18 - 18: rrRrRrer . IIiIiII11i
def iiIi1IIiI ( url ) :
 try :
  II1I1I1Ii = urllib2 . Request ( url )
  II1I1I1Ii . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0) Gecko/20100101 Firefox/19.0' )
  i1rRreRRre = urllib2 . urlopen ( II1I1I1Ii )
  RRrerrerRRRreR = i1rRreRRre . read ( )
  i1rRreRRre . close ( )
  RRrerrerRRRreR = RRrerrerRRRreR . replace ( '\n' , '' )
  return RRrerrerRRRreR
 except : pass
 if 82 - 82: rrereRrerr - rrereRrerr + rRrer
def II111Ii1i1 ( url ) :
 try :
  II1I1I1Ii = urllib2 . Request ( url )
  II1I1I1Ii . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0) Gecko/20100101 Firefox/19.0' )
  i1rRreRRre = urllib2 . urlopen ( II1I1I1Ii )
  RRrerrerRRRreR = i1rRreRRre . read ( )
  i1rRreRRre . close ( )
  RRrerrerRRRreR = RRrerrerRRRreR . replace ( '\n' , '' )
  return RRrerrerRRRreR
 except : pass
 if 98 - 98: RrrrererRrrerer . RrrrererRrrerer * Ii1I * iIiiiI1IiI1I1 * rRrerrerrRre
def rRrrRre ( url ) :
 I111iIi1 = RrereRrerRRrereRrere ( url )
 RRRrRrerere = iiIii ( I111iIi1 , '<link rel="next" href="' , '">' )
 I111iIi1 = iiIii ( I111iIi1 , "id='vListTop'>" , "<div id='adBottom'>" )
 I111iIi1 = rrrereRrererRrererer ( I111iIi1 )
 rRRRR = II ( I111iIi1 , "<div class='video'>" , "</div>" )
 i1i ( )
 for RrrerrRrrer in rRRRR :
  rrerererrrrRrer = iiIii ( RrrerrRrrer , "<a href='" , "'  " )
  rRrRrerrereRRre = iiIii ( RrrerrRrrer , 'alt="' , '"' )
  iI1i11 = iiIii ( RrrerrRrrer , "class='hRotator' ><img src='" , "' " )
  if len ( iI1i11 ) < 5 :
   iI1i11 = 'http://i.imgur.com/ajZJyfj.png'
  rRrRrerrereRRre = rRrRrerrereRRre . strip ( )
  rrRRrrrrrr = '[COLOR gold]' + rRrRrerrereRRre + '[/COLOR]'
  if 49 - 49: iIiiiI1IiI1I1 . Ii1I . RrreRrr % rrereRrerr
  url = iI1iIIIi1i ( rrerererrrrRrer )
  IiI1 ( rrRRrrrrrr , url , 3 , iI1i11 , isFolder = False )
  if 34 - 34: rRrerrerrRre % rrereRrerr
 if len ( RRRrRrerere ) > 10 :
  IiI1 ( '[B][COLOR yellow]Next Page >>>[/COLOR][/B]' , RRRrRrerere , 610 , Rrr )
  if 3 - 3: iIiiiI1IiI1I1 / iII111i + rrereRrerr . IIII . RrrrererRrrerer
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 83 - 83: Ii1I + iII111iiiii11
def iI1iIIIi1i ( url ) :
 I111iIi1 = RrereRrerRRrereRrere ( url )
 I111iIi1 = iiIii ( I111iIi1 , "file: '" , "'," )
 return I111iIi1
 if 22 - 22: I1Ii111 % rrRrRrer * iII111iiiii11 - RRrrRRr / iiiIIii1IIi
def RrRRrere ( url ) :
 if 28 - 28: Ii1I - RrreRrr . I11i + rrereRrerr / I11i
 Rrere = iiiIi
 i11iIiI11I1i = 0
 if 41 - 41: I1Ii111
 try : RrreRrereRrrerre = I11ii1 . http_GET ( Rrere + url ) . content
 except : return
 if 77 - 77: rRrerrerrRre
 RrreRrereRrrerre = RrreRrereRrrerre . encode ( 'ascii' , 'ignore' ) . decode ( 'ascii' )
 if 65 - 65: iIiiiI1IiI1I1 . IIiIiII11i % Ii1I * RrrrererRrrerer
 i1iIi1I1i = "50"
 if 38 - 38: rRrer / rrRrRrer % IiIIi1I1Iiii
 iIIIII1ii1I = re . compile ( 'FORMAT"(.+?)"' ) . findall ( RrreRrereRrrerre )
 if 11 - 11: rrRrRrer - Ii1I + iIiiiI1IiI1I1 - iiiIIii1IIi
 i1i ( )
 if 7 - 7: rrereRrerr - IiII / iIiiiI1IiI1I1 * I1Ii111 . rrRrRrer * rrRrRrer
 iiI111I1iIiI = II ( RrreRrereRrrerre , 'I:' , '"#' )
 for RrrerrRrrer in iiI111I1iIiI :
  Ii1i1 = iiIii ( RrrerrRrrer , 'I:"' , '"' )
  rrerererrrrRrer = iiIii ( RrrerrRrrer , 'A:"' , '"' )
  rRrRrerrereRRre = iiIii ( RrrerrRrrer , 'B:"' , '"' )
  I1I = iiIii ( RrrerrRrrer , 'C:"' , '"' )
  i11iIiI11I1i = 1
  IiI1 ( rRrRrerrereRRre , rrerererrrrRrer , Ii1i1 , I1I )
  if 61 - 61: IiII % IIII - RrrrererRrrerer / IiIIi1I1Iiii
 iiI111I1iIiI = II ( RrreRrereRrrerre , '<item>' , '</item>' )
 for RrrerrRrrer in iiI111I1iIiI :
  Ii1iI111 = ''
  rrerererrrrRrer = iiIii ( RrrerrRrrer , '<link>' , '</link>' ) . replace ( '  ' , ' ' )
  rRrRrerrereRRre = iiIii ( RrrerrRrrer , '<title>' , '</title>' )
  I1I = iiIii ( RrrerrRrrer , '<thumbnail>' , '</thumbnail>' )
  Ii1iI111 = iiIii ( RrrerrRrrer , '<fanart>' , '</fanart>' )
  if len ( Ii1iI111 ) < 5 :
   Ii1iI111 = I1I
  i11iIiI11I1i = 1
  IiI1 ( '[COLOR lime]' + rRrRrerrereRRre + '[/COLOR]' , rrerererrrrRrer , 3 , I1I , isFolder = False , background = Ii1iI111 )
  if 51 - 51: rrereRrerr * RRreRRreRreRre / iIiiiI1IiI1I1 . I1Ii111 % iII111i / IIiIiII11i
 RRrerrerRRRreR = II111Ii1i1 ( Rrere + url )
 RrereRRRrRrrreR = re . compile ( '#EXTINF:-1,(.+?)' ) . findall ( RRrerrerRRRreR )
 if 9 - 9: IIiIiII11i % IIiIiII11i % iIiiiI1IiI1I1
 if 30 - 30: rrereRrerr + rRrerrerrRre - rrereRrerr . rrereRrerr - iIiiiI1IiI1I1 + RRreRRreRreRre
 if 86 - 86: I1IiiI
 if 41 - 41: rRrer * IiII / rRrer % Ii1I
 if 18 - 18: iIiiiI1IiI1I1 . iII111iiiii11 % rRrer % I1Ii111
 if 9 - 9: RrrrererRrrerer - IiIIi1I1Iiii * iII111iiiii11 . IiIIi1I1Iiii
 if 2 - 2: iII111iiiii11 % iII111i
 list = rRrRRrrerrre ( Rrere + url )
 if 60 - 60: IIII * rRrerrerrRre + IiIIi1I1Iiii
 for IIi1i1IiIIi1i in list :
  rRrRrerrereRRre = common . GetEncodeString ( IIi1i1IiIIi1i [ "display_name" ] )
  Ii1i1 = 46 if IIi1i1IiIIi1i [ "url" ] . find ( "youtube" ) > 0 else 3
  url = common . GetEncodeString ( IIi1i1IiIIi1i [ "url" ] )
  url = url . replace ( '\\r' , '' ) . replace ( '\\t' , '' ) . replace ( '\r' , '' ) . replace ( '\t' , '' ) . replace ( ' ' , '' ) . replace ( 'm3u8' , 'm3u8' )
  url = rRRrreRRRRrreRr ( rRrRrerrereRRre , url )
  i11iiiiI1i ( rRrRrerrereRRre , url , 3 , RRrer , '' , '' )
  if 67 - 67: Ii1I / rrRrRrer . IiII . iiiIIii1IIi
 if i11iIiI11I1i == 1 :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 else :
  xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
  if 12 - 12: iII111iiiii11
def rRrRRrrerrre ( url ) :
 if 20 - 20: I1IiiI - IiII
 i1rRreRRre = requests . get ( url )
 i1rRreRRre = i1rRreRRre . content
 i1rRreRRre = i1rRreRRre . replace ( '#AAASTREAM:' , '#A:' )
 i1rRreRRre = i1rRreRRre . replace ( '#EXTINF:' , '#A:' )
 iII111iRrerererer = re . compile ( '^#A:-?[0-9]*(.*?),(.*?)\n(.*?)$' , re . I + re . M + re . U + re . S ) . findall ( i1rRreRRre )
 ii1ii11 = [ ]
 for RRrerRRrr , RrR , url in iII111iRrerererer :
  rrrerR = { "params" : RRrerRRrr , "display_name" : RrR , "url" : url }
  ii1ii11 . append ( rrrerR )
 list = [ ]
 for IIi1i1IiIIi1i in ii1ii11 :
  rrrerR = { "display_name" : IIi1i1IiIIi1i [ "display_name" ] , "url" : IIi1i1IiIIi1i [ "url" ] }
  iII111iRrerererer = re . compile ( ' (.+?)="(.+?)"' , re . I + re . M + re . U + re . S ) . findall ( IIi1i1IiIIi1i [ "params" ] )
  for iirrrerreRrRRR , rrRrerRrereRrer in iII111iRrerererer :
   rrrerR [ iirrrerreRrRRR . strip ( ) . lower ( ) . replace ( '-' , '_' ) ] = rrRrerRrereRrer . strip ( )
  list . append ( rrrerR )
  if 70 - 70: rRrerrerrRre
 return list
 if 16 - 16: rrRrRrer - iII111iiiii11 % IiIIi1I1Iiii
def rRRrreRRRRrreRr ( name , url ) :
 if 36 - 36: iII111i
 if '.ts' in url :
  url = 'plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER&amp;name=' + name + '&amp;url=' + url
 elif urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
  url = urlresolver . HostedMediaFile ( url ) . resolve ( )
 elif urlresolver . HostedMediaFile ( url ) . valid_url ( ) :
  url = urlresolver . HostedMediaFile ( url ) . resolve ( )
 elif liveresolver . isValid ( url ) == True :
  url = liveresolver . resolve ( url )
  if 84 - 84: rRrerrerrRre . RrrrererRrrerer . iIiiiI1IiI1I1 . IiII / I1Ii111 % I11i
 return url
 if 57 - 57: IIiIiII11i % IiII - iII111i . IIiIiII11i / IiIIi1I1Iiii % rrRrRrer
def RR ( url ) :
 if 16 - 16: rrereRrerr * rRrer . IIII / I1IiiI . RrrrererRrrerer - I1IiiI
 if "channel" in url :
  url = 'https://www.youtube.com/' + url
 elif "list=" in url :
  if 46 - 46: rrereRrerr + iiiIIii1IIi + iII111i + RrrrererRrrerer . I11i
  if 1 - 1: Ii1I
  if 62 - 62: I1IiiI - iII111i
  url = 'https://www.youtube.com/playlist?' + url
 else :
  url = 'https://www.youtube.com/user/' + url
  if 96 - 96: I1IiiI . I11i + Ii1I
 RRrerrerRRRreR = RrereRrerRRrereRrere ( url )
 if 48 - 48: iiiIIii1IIi % I1IiiI % rrRrRrer + IIII
 i1i ( )
 if 30 - 30: RrreRrr % iiiIIii1IIi . IiII % iiiIIii1IIi
 if "playlist" not in url :
  iiI111I1iIiI = II ( RRrerrerRRRreR , 'up-title ">' , 'class="yt-lock' )
  for RrrerrRrrer in iiI111I1iIiI :
   rRrRrerrereRRre = iiIii ( RrrerrRrrer , 'title="' , '"' ) . replace ( "&amp;" , "&" )
   rRrRrerrereRRre = rRRrererRrereRreRR ( rRrRrerrereRRre )
   url = iiIii ( RrrerrRrrer , 'href="' , '"' ) . replace ( "&amp;" , "&" )
   rRrrereRR = url [ 9 : ]
   I1I = 'http://i.ytimg.com/vi/' + str ( rRrrereRR ) + '/0.jpg'
   rRrrereRR = 'https://www.youtube.com/watch?v=' + rRrrereRR
   if not "list=" in rRrrereRR :
    if not "user" in url :
     i11iiiiI1i ( rRrRrerrereRRre , rRrrereRR , 60 , I1I , '' , '' )
 else :
  iiI111I1iIiI = II ( RRrerrerRRRreR , 'class="pl-video yt-uix-tile.+?">' , '<span class="thumb-menu dark' )
  for RrrerrRrrer in iiI111I1iIiI :
   rRrRrerrereRRre = iiIii ( RrrerrRrrer , 'title="' , '"' ) . replace ( "&amp;" , "&" )
   rRrRrerrereRRre = rRRrererRrereRreRR ( rRrRrerrereRRre )
   rRrrereRR = iiIii ( RrrerrRrrer , 'href="' , '"' ) . replace ( "&amp;" , "&" )
   rRrrereRR = rRrrereRR [ 9 : ]
   I1I = iiIii ( RrrerrRrrer , 'data-thumb="' , '"' ) . replace ( "&amp;" , "&" )
   rRrrereRR = 'https://www.youtube.com/watch?v=' + rRrrereRR
   i11iiiiI1i ( rRrRrerrereRRre , rRrrereRR , 60 , I1I , '' , '' )
   if 93 - 93: IiII - iiiIIii1IIi
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 39 - 39: RRrrRRr * IIII + I1Ii111 * iIiiiI1IiI1I1
def RrRrererre ( url ) :
 if 87 - 87: Ii1I * Ii1I / IIiIiII11i / IIII % iII111i
 i1i ( )
 if 96 - 96: IIiIiII11i % IiIIi1I1Iiii . I11i + iII111i
 if 'youtube.com' not in url :
  url = 'https://www.youtube.com/results?q=' + url . replace ( '"B:' , '' )
  if 42 - 42: iIiiiI1IiI1I1 * rrRrRrer * RrreRrr - iII111i . iII111iiiii11
 if "&page=" not in url :
  rrrerer = url + "&page=2"
  I1I11i = "1"
 else :
  RrrerrRrrer , Ii1I1I1i1Ii = url . split ( '&page=' )
  I1I11i = int ( float ( Ii1I1I1i1Ii ) )
  next = I1I11i + 1
  rrrerer = RrrerrRrrer + '&page=' + str ( next )
  if 76 - 76: rrRrRrer
 IiI1 ( "[COLOR yellow][B]PAGE " + str ( I1I11i ) + "[/B][/COLOR]" , '' , 6 , "http://i.imgur.com/BgEYv81.png" , isFolder = True )
 if 11 - 11: rrereRrerr % I11i % I1Ii111 / iIiiiI1IiI1I1 % rRrerrerrRre - IiIIi1I1Iiii
 import requests . packages . urllib3
 requests . packages . urllib3 . disable_warnings ( )
 ii1ii11IIIiiI = requests . get ( url )
 if 96 - 96: I11i / iIiiiI1IiI1I1 . I1Ii111 - rrRrRrer * IiII * Ii1I
 RrereRRRrRrrreR = re . compile ( 'yt-uix-tile"><div class="yt-lockup-thumbnail contains-addto"(.+?)<div class="yt-lockup-dismissable' , re . DOTALL ) . findall ( ii1ii11IIIiiI . content )
 if 76 - 76: I1Ii111 - iIiiiI1IiI1I1 * iII111i / iII111iiiii11
 for rrreRRr in RrereRRRrRrrreR :
  rRrRrerrereRRre = re . compile ( 'dir="ltr">(.+?)</a>' ) . findall ( rrreRRr ) [ 0 ]
  rRrrereRR = re . compile ( 'hidden="true"  href="(.+?)"' ) . findall ( rrreRRr ) [ 0 ]
  IIIiIi = re . compile ( 'https://i.ytimg.com(.+?)?custom' ) . findall ( rrreRRr ) [ 0 ]
  IIIiIi = "https://i.ytimg.com" + IIIiIi
  rRrRrerrereRRre = "[COLOR yellow]" + rRrRrerrereRRre + "[/COLOR]"
  rRrrereRR = rRrrereRR . replace ( '/watch?v=' , '' )
  IiI1 ( rRrRrerrereRRre , rRrrereRR , 60 , IIIiIi , isFolder = False )
  if 34 - 34: iII111iiiii11 . RRreRRreRreRre / Ii1I * rRrer - I11i
 IiI1 ( 'NEXT PAGE' , rrrerer , 59 , Rrr , isFolder = True )
 if 36 - 36: I1IiiI / RRreRRreRreRre / RrrrererRrrerer - RRreRRreRreRre - I1IiiI
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 22 - 22: I1IiiI + I1Ii111
def RrerreRreRRrerer ( url ) :
 IiI1 ( 'SEARCH' , url , 58 , 'http://.png' , isFolder = True )
 if 92 - 92: RRrrRRr + rRrerrerrRre / IiIIi1I1Iiii % RrrrererRrrerer % rrereRrerr . iII111iiiii11
def RreRr ( url ) :
 if 7 - 7: rrereRrerr % iiiIIii1IIi + IiII - I1Ii111 * Ii1I
 RRr = RrrRreRRrreRRrrerreRreR ( )
 RrRrererre ( url + RRr )
 if 9 - 9: I1Ii111
def RrrRreRRrreRRrrerreRreR ( ) :
 if 56 - 56: iIiiiI1IiI1I1 / Ii1I + RrreRrr + iII111i
 RRr = ''
 iII1 = xbmc . Keyboard ( RRr , 'Reaper Search' )
 iII1 . doModal ( )
 if iII1 . isConfirmed ( ) :
  RRr = iII1 . getText ( ) . replace ( ' ' , '+' )
  if 54 - 54: I1Ii111 - IiII - rRrerrerrRre . iiiIIii1IIi
 return RRr
 if 79 - 79: I1Ii111 . RrrrererRrrerer
def IIiI1I1 ( text , pattern ) :
 ii1ii11IIIiiI = ""
 try :
  iII111iRrerererer = re . findall ( pattern , text , flags = re . DOTALL )
  ii1ii11IIIiiI = iII111iRrerererer [ 0 ]
 except :
  ii1ii11IIIiiI = ""
  if 15 - 15: I1Ii111 * IiIIi1I1Iiii % I11i * iiiIIii1IIi - RrreRrr
 return ii1ii11IIIiiI
 if 60 - 60: IIiIiII11i * rRrerrerrRre % RrrrererRrrerer + Ii1I
 if 52 - 52: I1IiiI
def rrerere ( url ) :
 RRrrrreR = str ( base64 . decodestring ( RrrRreRR ) )
 RRrerrerRRRreR = RrereRrerRRrereRrere ( RRrrrreR + url )
 if 34 - 34: iII111i
 IiIIiIIIiIii = '<div class="cover"><a href="(.+?)" rel="bookmark" title="(.+?)">.+?<img src="(.+?)".+?<p class="postmetadata longdate" rel=".+?">(.+?)/(.+?)/(.+?)</p>'
 RrereRRRrRrrreR = re . compile ( IiIIiIIIiIii , re . DOTALL ) . findall ( RRrerrerRRRreR )
 i1i ( )
 for rrerererrrrRrer , rRrRrerrereRRre , iI1i11 , I1i11II , II11 , I1iI1iIi111i in RrereRRRrRrrreR :
  I1iii = '%s/%s/%s' % ( II11 , I1i11II , I1iI1iIi111i )
  rRrRrerrereRRre = '%s-[COLOR gold][%s][/COLOR]' % ( rRrRrerrereRRre , I1iii )
  IiI1 ( rRrRrerrereRRre , rrerererrrrRrer , 152 , iI1i11 )
  if 51 - 51: I11i
 I1i1i1 = re . compile ( '</span><a class="page larger" href="(.+?)">' ) . findall ( RRrerrerRRRreR )
 if I1i1i1 :
  rrerererrrrRrer = str ( I1i1i1 )
  rrerererrrrRrer = rrerererrrrRrer . replace ( '[u\'' , '' )
  rrerererrrrRrer = rrerererrrrRrer . replace ( ']' , '' )
  rrerererrrrRrer = rrerererrrrRrer . replace ( '\'' , '' )
  IiI1 ( '[B][COLOR yellow]Next Page >>>[/COLOR][/B]' , rrerererrrrRrer , 151 , "http://i.imgur.com/ajZJyfj.png" )
  if 41 - 41: I11i * IIII - I1Ii111 + IiIIi1I1Iiii
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 23 - 23: iIiiiI1IiI1I1 % RRrrRRr + RRrrRRr + rrRrRrer - rrRrRrer
def rRrreRrereR ( ) :
 iiIii1I = ''
 iII1 = xbmc . Keyboard ( iiIii1I , 'Search Reaper Replays' )
 iII1 . doModal ( )
 if iII1 . isConfirmed ( ) :
  iiIii1I = iII1 . getText ( ) . replace ( ' ' , '+' )
  if iiIii1I == None :
   return False
 RRrerrerRRRreR = i1I11iIiII ( 'http://www.google.com/cse?cx=partner-pub-9069051203647610:8413886168&ie=UTF-8&q=%s&sa=Search&ref=livefootballvideo.com/highlights' % iiIii1I )
 RrereRRRrRrrreR = re . compile ( '" href="(.+?)" onmousedown=".+?">(.+?)</a>' ) . findall ( RRrerrerRRRreR )
 for rrrreR , RRreRRreRR in RrereRRRrRrrreR :
  import HTMLParser
  RrrrRrer = HTMLParser . HTMLParser ( ) . unescape ( RRreRRreRR )
  rRrRrerrereRRre = RrrrRrer . replace ( '<b>' , '' ) . replace ( '</b>' , '' )
  IiI1 ( rRrRrerrereRRre , rrrreR , 152 , '' )
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 24 - 24: rRrer % I1IiiI + rrRrRrer . RrreRrr . I11i
def IIi1II ( name , url ) :
 RRrerrerRRRreR = RrereRrerRRrereRrere ( url )
 i1i ( )
 if "proxy.link=lfv*" in RRrerrerRRRreR :
  import decrypter
  RrereRRRrRrrreR = re . compile ( 'proxy\.link=lfv\*(.+?)&' ) . findall ( RRrerrerRRRreR )
  RrereRRRrRrrreR = IiiI11i1I ( RrereRRRrRrrreR )
  RrereRRRrRrrreR = [ decrypter . decrypter ( 198 , 128 ) . decrypt ( RRRreRRRrererr , base64 . urlsafe_b64decode ( 'Y0ZNSENPOUhQeHdXbkR4cWJQVlU=' ) , 'ECB' ) . split ( '\0' ) [ 0 ] for RRRreRRRrererr in RrereRRRrRrrreR ]
  for url in RrereRRRrRrrreR :
   if 80 - 80: iII111i / IiII / rRrer + I1IiiI - IiIIi1I1Iiii
   url = rRRrererRrereRreRR ( url )
   if url . startswith ( '//' ) : url = 'http:' + url
   url = url . encode ( 'utf-8' )
   iIIiiIIi1IiI = url . split ( '://' ) [ 1 ]
   iIIiiIIi1IiI = iIIiiIIi1IiI . split ( '/' ) [ 0 ] . upper ( )
   I11IIIiIi11 ( name + ' - [COLOR red]%s[/COLOR]' % iIIiiIIi1IiI , url , 120 , RrRrerere , '' )
 if "www.youtube.com/embed/" in RRrerrerRRRreR :
  IiIIiIIIiIii = 'youtube.com/embed/(.+?)"'
  RrereRRRrRrrreR = re . compile ( IiIIiIIIiIii , re . DOTALL ) . findall ( RRrerrerRRRreR )
  I11iiIi1i1 = RrereRRRrRrrreR [ 0 ]
  iI1i11 = 'http://i.ytimg.com/vi/%s/0.jpg' % I11iiIi1i1 . replace ( '?rel=0' , '' )
  url = 'plugin://plugin.video.youtube/?path=root/video&action=play_video&videoid=%s' % I11iiIi1i1 . replace ( '?rel=0' , '' )
  I11IIIiIi11 ( name + ' - [COLOR red]YOUTUBE[/COLOR]' , url , 120 , iI1i11 , '' )
 if "dailymotion.com" in RRrerrerRRRreR :
  IiIIiIIIiIii = 'src="http://www.dailymotion.com/embed/video/(.+?)\?.+?"></iframe>'
  RrereRRRrRrrreR = re . compile ( IiIIiIIIiIii , re . DOTALL ) . findall ( RRrerrerRRRreR )
  for url in RrereRRRrRrrreR :
   I11IIIiIi11 ( name + ' - [COLOR red]DAILYMOTION[/COLOR]' , url , 120 , RrRrerere , '' )
 if "http://videa" in RRrerrerRRRreR :
  IiIIiIIIiIii = 'http://videa.+?v=(.+?)"'
  RrereRRRrRrrreR = re . compile ( IiIIiIIIiIii , re . DOTALL ) . findall ( RRrerrerRRRreR )
  for url in RrereRRRrRrrreR :
   I11IIIiIi11 ( name + ' - [COLOR red]VIDEA[/COLOR]' , url , 120 , RrRrerere , '' )
   if 41 - 41: I1Ii111 % I11i
 if "rutube.ru" in RRrerrerRRRreR :
  IiIIiIIIiIii = 'ttp://rutube.ru/video/embed/(.+?)\?'
  RrereRRRrRrrreR = re . compile ( IiIIiIIIiIii , re . DOTALL ) . findall ( RRrerrerRRRreR )
  for url in RrereRRRrRrrreR :
   I11IIIiIi11 ( name + ' - [COLOR red]RUTUBE[/COLOR]' , url , 120 , RrRrerere , '' )
 if 'cdn.playwire.com' in RRrerrerRRRreR :
  IiIIiIIIiIii = 'cdn.playwire.com/bolt/js/embed.min.js.+?data-publisher-id="(.+?)".+?data-config="(.+?)">'
  RrereRRRrRrrreR = re . compile ( IiIIiIIIiIii , re . DOTALL ) . findall ( RRrerrerRRRreR )
  for id , i1iIiIi1I in RrereRRRrRrrreR :
   if 37 - 37: I1Ii111 % RrrrererRrrerer
   url = i1iIiIi1I . replace ( 'player.json' , 'manifest.f4m' )
   I11IIIiIi11 ( name + ' - [COLOR red]PLAYWIRE[/COLOR]' , url , 120 , RrRrerere , '' )
 if "vk.com" in RRrerrerRRRreR :
  IiIIiIIIiIii = '<iframe src="http://vk.com/(.+?)"'
  RrereRRRrRrrreR = re . compile ( IiIIiIIIiIii , re . DOTALL ) . findall ( RRrerrerRRRreR )
  for url in RrereRRRrRrrreR :
   I11IIIiIi11 ( name + ' - [COLOR red]VK.COM[/COLOR]' , 'http://vk.com/' + url , 120 , RrRrerere , '' )
 if "mail.ru" in RRrerrerRRRreR :
  IiIIiIIIiIii = 'http://videoapi.my.mail.ru/videos/embed/(.+?)\.html'
  RrereRRRrRrrreR = re . compile ( IiIIiIIIiIii , re . DOTALL ) . findall ( RRrerrerRRRreR )
  for url in RrereRRRrRrrreR :
   I11IIIiIi11 ( name + ' - [COLOR red]MAIL.RU[/COLOR]' , 'http://videoapi.my.mail.ru/videos/%s.json' % url , 120 , RrRrerere , '' )
   if 79 - 79: I11i + IIiIiII11i / IIiIiII11i
   if 71 - 71: iII111i * RrrrererRrrerer % iII111iiiii11 % RrrrererRrrerer / IIiIiII11i
def RrrerrrreRrr ( name , url , iconimage ) :
 if 'YOUTUBE' in name :
  RRrerrerRRRreR = str ( url )
 elif 'VIDEA' in name :
  try :
   url = url . split ( '-' ) [ 1 ]
  except :
   url = url
  RRrerrerRRRreR = GrabVidea ( url )
 elif 'VK.COM' in name :
  RRrerrerRRRreR = GrabVK ( url )
  if 9 - 9: IiIIi1I1Iiii
 elif 'MAIL.RU' in name :
  RRrerrerRRRreR = RreRrereRRr ( url )
  if 66 - 66: RrreRrr / RRrrRRr - iII111iiiii11 / I1IiiI . RrreRrr
  if 16 - 16: IiIIi1I1Iiii % I11i + IiII - RRreRRreRreRre . rrRrRrer / rRrerrerrRre
 elif 'RUTUBE' in name :
  try :
   IIi1I = 'http://rutube.ru/api/play/trackinfo/%s/?format=xml' % url . replace ( '_ru' , '' )
   RRrerrerRRRreR = I11ii1 . http_GET ( IIi1I ) . content
   IiIIiIIIiIii = '<m3u8>(.+?)</m3u8>'
   RrereRRRrRrrreR = re . compile ( IiIIiIIIiIii , re . DOTALL ) . findall ( RRrerrerRRRreR )
   if RrereRRRrRrrreR :
    RRrerrerRRRreR = RrereRRRrRrrreR [ 0 ]
   else :
    Rr = xbmcgui . Dialog ( )
    Rr . ok ( "Football Replays" , '' , 'Sorry Video Is Private' , '' )
    return
  except :
   Rr = xbmcgui . Dialog ( )
   Rr . ok ( "Football Replays" , '' , 'Sorry Video Is Private' , '' )
   return
 elif 'PLAYWIRE' in name :
  RRrerrerRRRreR = I11ii1 . http_GET ( url ) . content
  if 27 - 27: RRreRRreRreRre . rRrerrerrRre / rrRrRrer
  IiIIiIIIiIii = '<baseURL>(.+?)</baseURL>.+?media url="(.+?)"'
  RrereRRRrRrrreR = re . compile ( IiIIiIIIiIii , re . DOTALL ) . findall ( RRrerrerRRRreR )
  if RrereRRRrRrrreR :
   RRrerrerRRRreR = RrereRRRrRrrreR [ 0 ] [ 0 ] + '/' + RrereRRRrRrrreR [ 0 ] [ 1 ]
   if 96 - 96: I11i % IIII % I1Ii111 - IIII % rRrer + I11i
   if 3 - 3: RRreRRreRreRre
 elif 'DAILYMOTION' in name :
  try :
   url = url . split ( 'video/' ) [ 1 ]
  except :
   url = url
  RRrerrerRRRreR = RrrreRrrerrre ( url )
 try :
  RreRrrr = xbmcgui . ListItem ( name , iconImage = RrRrerere , thumbnailImage = iconimage )
  RreRrrr . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
  RreRrrr . setProperty ( "IsPlayable" , "true" )
  RreRrrr . setPath ( RRrerrerRRRreR )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , RreRrrr )
 except : pass
 if 83 - 83: rRrerrerrRre
 if 48 - 48: iIiiiI1IiI1I1 * iII111i * rRrerrerrRre
def RreRrereRRr ( url ) :
 print 'RESOLVING VIDEO.MAIL.RU VIDEO API LINK'
 if 50 - 50: rrereRrerr % I1IiiI
 iii11II1I = [ ]
 iI11iI1IiiIiI = "???"
 iI111I11i = I1 ( url )
 II1i11I1 = I11ii1 . get_cookies ( )
 for ii1Ii11I in II1i11I1 :
  if 2 - 2: IIiIiII11i - Ii1I
  for IIIIiI1iiiIiii in II1i11I1 [ ii1Ii11I ] :
   if 24 - 24: iiiIIii1IIi + iiiIIii1IIi * rrRrRrer
   for i1I11iIII1i1I in II1i11I1 [ ii1Ii11I ] [ IIIIiI1iiiIiii ] :
    if 63 - 63: IiIIi1I1Iiii + rRrerrerrRre - iIiiiI1IiI1I1
    i1iIIi1I1I11 = ( II1i11I1 [ ii1Ii11I ] [ IIIIiI1iiiIiii ] [ i1I11iIII1i1I ] )
 rRrRrerrereRRre = [ ]
 url = [ ]
 IiIIiIIIiIii = '"key":"(.+?)","url":"(.+?)"'
 RrereRRRrRrrreR = re . compile ( IiIIiIIIiIii , re . DOTALL ) . findall ( iI111I11i )
 for iI11iI1IiiIiI , iii1III1i in RrereRRRrRrrreR :
  rRrRrerrereRRre . append ( iI11iI1IiiIiI . title ( ) )
  if 17 - 17: iIiiiI1IiI1I1 / iIiiiI1IiI1I1
  if 65 - 65: rrereRrerr + IiIIi1I1Iiii
  if 59 - 59: iII111iiiii11 + IiII . rRrerrerrRre - RRreRRreRreRre % iiiIIii1IIi / RRreRRreRreRre
  RRrrRrer = str ( i1iIIi1I1I11 )
  RRrrRrer = RRrrRrer . replace ( '<Cookie ' , '' )
  RRrrRrer = RRrrRrer . replace ( ' for .my.mail.ru/>' , '' )
  url . append ( iii1III1i + '|Cookie=' + RRrrRrer )
  if 25 - 25: iiiIIii1IIi - rrRrRrer
 return url [ xbmcgui . Dialog ( ) . select ( 'Please Select Resolution' , rRrRrerrereRRre ) ]
 if 3 - 3: IIiIiII11i * IIII + iIiiiI1IiI1I1 - RrrrererRrrerer
def I1 ( url , headers = { } ) :
 I11ii1 . save_cookies ( RrrreRRrerRR )
 II1I1I1Ii = urllib2 . Request ( url )
 II1I1I1Ii . add_header ( 'User-Agent' , rrrrrrRrerr )
 i1rRreRRre = urllib2 . urlopen ( II1I1I1Ii )
 iI111I11i = i1rRreRRre . read ( )
 i1rRreRRre . close ( )
 return iI111I11i
 if 97 - 97: I11i / Ii1I - RRrrRRr - IIiIiII11i - IIiIiII11i
def I11IIIiIi11 ( name , url , mode , iconimage , page ) :
 rrr = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&page=" + str ( page )
 iIIii = True
 RreRrrr = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 RreRrrr . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 if mode == 120 :
  RreRrrr . setProperty ( "IsPlayable" , "true" )
  iIIii = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = rrr , listitem = RreRrrr , isFolder = False )
 else :
  iIIii = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = rrr , listitem = RreRrrr , isFolder = True )
 return iIIii
 if 54 - 54: IiIIi1I1Iiii + IIiIiII11i / rrRrRrer . IIiIiII11i * rRrer
def IiiI11i1I ( name ) :
 IIiIiiiIIIIi1 = [ ]
 for iIi11 in name :
  if iIi11 not in IIiIiiiIIIIi1 :
   IIiIiiiIIIIi1 . append ( iIi11 )
 return IIiIiiiIIIIi1
 if 81 - 81: IiII / RrrrererRrrerer % iII111iiiii11 * Ii1I / Ii1I
def rRRrererRrereRreRR ( txt ) :
 import HTMLParser
 if 28 - 28: RrreRrr / RRrrRRr . iiiIIii1IIi / iIiiiI1IiI1I1
 if 72 - 72: iII111iiiii11 / IIiIiII11i + I1Ii111 / rRrer * I1Ii111
 txt = re . sub ( "(&#[0-9]+)([^;^0-9]+)" , "\\1;\\2" , Ii1iIi111i1i1 ( txt ) )
 if 45 - 45: rRrer . RRrrRRr % rRrer * IIiIiII11i % IIiIiII11i
 txt = HTMLParser . HTMLParser ( ) . unescape ( txt )
 txt = txt . replace ( "&amp;" , "&" )
 return txt
 if 63 - 63: rRrerrerrRre
def Ii1iIi111i1i1 ( data ) :
 return data
 try :
  return data . decode ( 'utf8' , 'xmlcharrefreplace' )
 except :
  rrrererrRrr = u""
  for RRRreRRRrererr in data :
   try :
    RRRreRRRrererr . decode ( "utf8" , "xmlcharrefreplace" )
   except :
    log ( "Can't convert character" , 4 )
    continue
   else :
    rrrererrRrr += RRRreRRRrererr
  return rrrererrRrr
  if 28 - 28: I1Ii111
def RrrreRrrerrre ( id ) :
 iIIIiiiI11I = "1080p"
 I1ii1111Ii = I11ii1 . http_GET ( "http://www.dailymotion.com/embed/video/" + id ) . content
 if 69 - 69: rrereRrerr . RrrrererRrrerer + iIiiiI1IiI1I1
 if I1ii1111Ii . find ( '"statusCode":410' ) > 0 or I1ii1111Ii . find ( '"statusCode":403' ) > 0 :
  xbmc . executebuiltin ( 'XBMC.Notification(Info:,Not Found (DailyMotion)!,5000)' )
  return ""
 else :
  rRrerRrrrrRrR = re . compile ( '"stream_h264_hd1080_url":"(.+?)"' , re . DOTALL ) . findall ( I1ii1111Ii )
  i1rRRRRRRRrR = re . compile ( '"stream_h264_hd_url":"(.+?)"' , re . DOTALL ) . findall ( I1ii1111Ii )
  I1IIiI = re . compile ( '"stream_h264_hq_url":"(.+?)"' , re . DOTALL ) . findall ( I1ii1111Ii )
  RrerRRrrer = re . compile ( '"stream_h264_url":"(.+?)"' , re . DOTALL ) . findall ( I1ii1111Ii )
  I1III11iiii11i1 = re . compile ( '"stream_h264_ld_url":"(.+?)"' , re . DOTALL ) . findall ( I1ii1111Ii )
  rrrreR = ""
  if rRrerRrrrrRrR and iIIIiiiI11I == "1080p" :
   rrrreR = urllib . unquote_plus ( rRrerRrrrrRrR [ 0 ] ) . replace ( "\\" , "" )
  elif i1rRRRRRRRrR and ( iIIIiiiI11I == "720p" or iIIIiiiI11I == "1080p" ) :
   rrrreR = urllib . unquote_plus ( i1rRRRRRRRrR [ 0 ] ) . replace ( "\\" , "" )
  elif I1IIiI :
   rrrreR = urllib . unquote_plus ( I1IIiI [ 0 ] ) . replace ( "\\" , "" )
  elif RrerRRrrer :
   rrrreR = urllib . unquote_plus ( RrerRRrrer [ 0 ] ) . replace ( "\\" , "" )
  elif I1III11iiii11i1 :
   rrrreR = urllib . unquote_plus ( I1III11iiii11i1 [ 0 ] ) . replace ( "\\" , "" )
  return rrrreR
  if 54 - 54: I1IiiI - Ii1I
def IiIIII ( url ) :
 rRRrrrrerRre = xbmc . Keyboard ( '' , 'Reaper Search TV Shows' )
 rRRrrrrerRre . doModal ( )
 if ( rRRrrrrerRre . isConfirmed ( ) ) :
  i1i ( )
  IIi11i1II = rRRrrrrerRre . getText ( )
  RRrerrrrerre = urllib . quote ( IIi11i1II )
  url = 'search.php?key=' + RRrerrrrerre
  RrreRrereRrrerre = RrereRrerRRrereRrere ( RrreRrRrererRRrer ( 'TV1' ) + url )
  RrreRrereRrrerre = iiIii ( RrreRrereRrrerre , '<div class="found">' , '</div>' )
  RrreRrereRrrerre = rrrereRrererRrererer ( RrreRrereRrrerre )
  rRrerrRrR = II ( RrreRrereRrrerre , '<ul><li>' , '</li></ul>' )
  for RrrerrRrrer in rRrerrRrR :
   url = iiIii ( RrrerrRrrer , '<a href="' , '"' )
   rRrRrerrereRRre = iiIii ( RrrerrRrrer , '">' , '<' ) . lstrip ( )
   rRrRrerrereRRre = rrRrererererrereR ( rRrRrerrereRRre )
   IiI1 ( rRrRrerrereRRre , url , 87 , IIiiIiI1 , background = RrreRrRrererRRrer ( 'TVBackground' ) )
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 91 - 91: IiII / RRreRRreRreRre - I1Ii111 . IIiIiII11i
 if 82 - 82: rrereRrerr * iII111i / Ii1I
def IiiIiI ( url ) :
 RrreRrereRrrerre = RrereRrerRRrereRrere ( RrreRrRrererRRrer ( 'TV1' ) + url )
 RrreRrereRrrerre = iiIii ( RrreRrereRrrerre , '<div class="home">' , '</div>' )
 RrreRrereRrrerre = rrrereRrererRrererer ( RrreRrereRrrerre )
 i1i ( )
 RrereRRRrRrrreR = re . compile ( '<li><a href="/(.+?)">(.+?)</a></li>' , re . DOTALL ) . findall ( str ( RrreRrereRrrerre ) )
 for url , rRrRrerrereRRre in RrereRRRrRrrreR :
  rRrRrerrereRRre = rrRrererererrereR ( rRrRrerrereRRre )
  iIIIIiiIii = url . replace ( '/' , '' )
  IiI1 ( rRrRrerrereRRre , url , 87 , IIiiIiI1 , background = RrreRrRrererRRrer ( 'TVBackground' ) )
  if 58 - 58: IiIIi1I1Iiii
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 9 - 9: iiiIIii1IIi % I11i . iII111i + iII111iiiii11
def Rrrer ( url ) :
 RrreRrereRrrerre = RrereRrerRRrereRrere ( RrreRrRrererRRrer ( 'TV1' ) + url )
 RrreRrereRrrerre = iiIii ( RrreRrereRrrerre , '<div class="leftpage_top">' , '<div class="addthis">' )
 RrreRrereRrrerre = rrrereRrererRrererer ( RrreRrereRrrerre )
 i1i ( )
 RrereRRRrRrrreR = re . compile ( "<h3><a href='/(.+?)'>(.+?)</a></h3>" , re . DOTALL ) . findall ( str ( RrreRrereRrrerre ) )
 for url , rRrRrerrereRRre in RrereRRRrRrrreR :
  rRrRrerrereRRre = rrRrererererrereR ( rRrRrerrereRRre )
  IiI1 ( rRrRrerrereRRre , url , 88 , IIiiIiI1 , background = RrreRrRrererRRrer ( 'TVBackground' ) )
  if 93 - 93: iII111i
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 43 - 43: I11i / IIiIiII11i . IIII
def RrrrerRre ( url ) :
 RrreRrereRrrerre = RrereRrerRRrereRrere ( RrreRrRrererRRrer ( 'TV1' ) + url )
 RrreRrereRrrerre = iiIii ( RrreRrereRrrerre , '<h3>' , '<div class="addthis">' )
 RrreRrereRrrerre = rrrereRrererRrererer ( RrreRrereRrrerre )
 i1i ( )
 RrereRRRrRrrreR = re . compile ( "<a href='/(.+?)'><strong>(.+?)</a>" , re . DOTALL ) . findall ( str ( RrreRrereRrrerre ) )
 for url , rRrRrerrereRRre in RrereRRRrRrrreR :
  rRrRrerrereRRre = rrRrererererrereR ( rRrRrerrereRRre )
  rRrRrerrereRRre = re . sub ( RrererreRR , '' , rRrRrerrereRRre )
  IiI1 ( rRrRrerrereRRre , url , 81 , IIiiIiI1 , background = RrreRrRrererRRrer ( 'TVBackground' ) )
  if 86 - 86: RRreRRreRreRre
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 95 - 95: rrRrRrer * iII111i . rRrer . I1IiiI . I1IiiI - RRrrRRr
def RrereRrerRRrereRrere ( url ) :
 ii1iIIiii1 = I11ii1 . http_GET ( url ) . content
 ii1iIIiii1 = ii1iIIiii1 . encode ( 'ascii' , 'ignore' ) . decode ( 'ascii' )
 return ii1iIIiii1
 if 62 - 62: iII111i
def i1I1i ( url ) :
 RrreRrereRrrerre = RrereRrerRRrereRrere ( RrreRrRrererRRrer ( 'TV1' ) + url )
 RrreRrereRrrerre = iiIii ( RrreRrereRrrerre , '<div class="home">' , '</div>' )
 RrreRrereRrrerre = rrrereRrererRrererer ( RrreRrereRrrerre )
 i1i ( )
 if 87 - 87: IiIIi1I1Iiii / RRreRRreRreRre * rrereRrerr / RRrrRRr
 RrereRRRrRrrreR = re . compile ( '<li><a href="/(.+?)">(.+?)</a></li>' , re . DOTALL ) . findall ( RrreRrereRrrerre )
 for url , rRrRrerrereRRre in RrereRRRrRrrreR :
  rRrRrerrereRRre = rrRrererererrereR ( rRrRrerrereRRre )
  url = url + '/'
  IiI1 ( rRrRrerrereRRre , url , 81 , IIiiIiI1 , background = RrreRrRrererRRrer ( 'TVBackground' ) )
  if 19 - 19: rRrerrerrRre + I1IiiI . IIiIiII11i - IiIIi1I1Iiii
 xbmcplugin . addSortMethod ( handle = int ( sys . argv [ 1 ] ) , sortMethod = xbmcplugin . SORT_METHOD_LABEL )
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 16 - 16: Ii1I + IIII / RRrrRRr
 if 82 - 82: rrereRrerr * RrreRrr % iIiiiI1IiI1I1 - iII111iiiii11
def RRre ( url ) :
 RrreRrereRrrerre = RrereRrerRRrereRrere ( url )
 RrreRrereRrrerre = rrrereRrererRrererer ( RrreRrereRrrerre )
 RrreRrereRrrerre = iiIii ( RrreRrereRrrerre , '<div class="leftpage_frame">' , '<div class="foot"' )
 i1i ( )
 RrereRRRrRrrreR = re . compile ( '<li><a href="/(.+?)" >(.+?)</a></li><li>' , re . DOTALL ) . findall ( str ( SelectOut ) )
 for url , rRrRrerrereRRre in RrereRRRrRrrreR :
  rRrRrerrereRRre = rrRrererererrereR ( rRrRrerrereRRre )
  iIIIIiiIii = url . replace ( '/' , '' )
  IiI1 ( rRrRrerrereRRre , url , 80 , IIiiIiI1 , background = RrreRrRrererRRrer ( 'TVBackground' ) )
  if 62 - 62: I1IiiI / IIII . IIiIiII11i * RRrrRRr
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 21 - 21: RRrrRRr
def RreRrre ( url ) :
 rrerRrerrrererereRR = RrereRrerRRrereRrere ( RrreRrRrererRRrer ( 'TV1' ) + url )
 if '<h1>Latest Added</h1>' in rrerRrerrrererereRR :
  rrerRrerrrererereRR = iiIii ( rrerRrerrrererereRR , '<div class="home">' , '<div align="center" class="foot">' )
  RrereRRRrRrrreR = re . compile ( '<a href="/(.+?)">(.+?)</a>' ) . findall ( str ( rrerRrerrrererereRR ) )
 elif '<h1>Most Popular</h1>' in rrerRrerrrererereRR :
  rrerRrerrrererereRR = iiIii ( rrerRrerrrererereRR , '<div class="home">' , '<div align="center" class="foot">' )
  RrereRRRrRrrreR = re . compile ( '<a href="/(.+?)">(.+?)</a>' ) . findall ( str ( rrerRrerrrererereRR ) )
 elif '<h1>Genres</h1>' in rrerRrerrrererereRR :
  rrerRrerrrererereRR = iiIii ( rrerRrerrrererereRR , '<div class="home">' , '<div align="center" class="foot">' )
  RrereRRRrRrrreR = re . compile ( '<a href="/(.+?)">(.+?)</a>' ) . findall ( str ( rrerRrerrrererereRR ) )
  if 45 - 45: rRrerrerrRre * I1Ii111 / iII111iiiii11 . Ii1I % I11i / I1IiiI
 i1i ( )
 for url , rRrRrerrereRRre in RrereRRRrRrrreR :
  IiI1 ( rRrRrerrereRRre , url , 87 , IIiiIiI1 , background = RrreRrRrererRRrer ( 'TVBackground' ) )
  if 24 - 24: iII111i + RRrrRRr + IiII - rrereRrerr + rRrer
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 14 - 14: I1Ii111 . RrreRrr
def i11i111IiI ( name , url ) :
 i1i1II11II1 = RrereRrerRRrereRrere ( RrreRrRrererRRrer ( 'TV1' ) + url )
 i1i1II11II1 = rrrereRrererRrererer ( i1i1II11II1 )
 i1i1II11II1 = iiIii ( i1i1II11II1 , '<div id="linkname">' , '</table>' )
 rRrerrRrR = II ( i1i1II11II1 , '<ul id="linkname_nav">' , '</a></li>' )
 i1i ( )
 II1IIIii = [ ] ; iIIIiIi1I1i = [ ] ; i1 = 0
 for RrrerrRrrer in rRrerrRrR :
  url = iiIii ( RrrerrRrrer , 'http://' , ';' )
  url = url . replace ( "')" , "" )
  RrRRrRrerRr = iiIii ( RrrerrRrrer , ';">' , '</a></li>' ) . lstrip ( )
  i1 = i1 + 1 ; II1IIIii . append ( 'Reaper Link [' + str ( i1 ) + '] ' + RrRRrRrerRr ) ; iIIIiIi1I1i . append ( url )
  if 70 - 70: IiII % iiiIIii1IIi . IiIIi1I1Iiii + IiIIi1I1Iiii - RRrrRRr % rRrerrerrRre
 Rr = xbmcgui . Dialog ( )
 i1IIi1i1Ii1 = Rr . select ( 'Reaper Select A Source' , II1IIIii )
 if i1IIi1i1Ii1 >= 0 :
  Iii = II1IIIii [ i1IIi1i1Ii1 ]
  rreRrrerR = str ( "http://" + iIIIiIi1I1i [ i1IIi1i1Ii1 ] )
  IiI1 ( '[COLOR yellow]Replay ' + name + '[/COLOR]' , str ( rreRrrerR ) , 68 , IIiiIiI1 , background = RrreRrRrererRRrer ( 'TVBackground' ) , isFolder = False )
  iIII1iiIi11 ( name , rreRrrerR , IIiiIiI1 )
 else :
  pass
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 84 - 84: RrreRrr * RrrrererRrrerer
 if 18 - 18: iII111i - I1Ii111 - rRrer / rRrerrerrRre - RRreRRreRreRre
def iIII1iiIi11 ( name , url3 , thumb ) :
 rrrreR = url3
 try :
  II1I1I1Ii = urllib2 . Request ( url3 )
  II1I1I1Ii . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
  rrrreR = url3
  RRRRrRrererreR = urlresolver . resolve ( urllib2 . urlopen ( II1I1I1Ii ) . url )
  RreRrrr = xbmcgui . ListItem ( name , iconImage = iI1i11 , thumbnailImage = iI1i11 ) ; RreRrrr . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
  if 30 - 30: RRreRRreRreRre + I11i + iIiiiI1IiI1I1
  if 14 - 14: RRrrRRr / iII111i - iiiIIii1IIi - Ii1I % IIII
  I1iIiI1IiIIII ( name , RRRRrRrererreR , thumb )
 except :
  if len ( url3 ) > 0 :
   II11IiiIII ( 'small' , 'Sorry Link Removed:' , 'Please try another one.' , 9000 )
   if 18 - 18: IIII % RrreRrr . iiiIIii1IIi - rrRrRrer
def I1iIiI1IiIIII ( name , streamlink , thumb ) :
 iIIii = True
 try : addon . resolve_url ( streamlink )
 except : pass
 RreRrrr = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iI1i11 )
 RreRrrr . setInfo ( 'Video' , infoLabels = { "Title" : name } )
 RRRRrr = [ ]
 RreRrrr . addContextMenuItems ( RRRRrr , replaceItems = True )
 xbmc . Player ( ) . play ( streamlink , RreRrrr )
 if 29 - 29: RRrrRRr / RrreRrr / IIiIiII11i % Ii1I % RrreRrr
 if 18 - 18: iII111i + rRrerrerrRre
 if 80 - 80: Ii1I + RRrrRRr * I1Ii111 + RrrrererRrrerer
def RrerRr ( url ) :
 RRrerrreRreRRRre = ''
 try :
  RRrerrreRreRRRre = I11ii1 . http_GET ( RrreRrRrererRRrer ( 'MOVIELINK1' ) + url ) . content
 except :
  RRrerrreRreRRRre = I11ii1 . http_GET ( RrreRrRrererRRrer ( 'MOVIELINK2' ) + url ) . content
  if 76 - 76: RrreRrr / rRrer + rRrer / I1IiiI * IIiIiII11i
 return RRrerrreRreRRRre
 if 12 - 12: rRrerrerrRre % RrreRrr + RRrrRRr + rRrerrerrRre / IiII
 if 53 - 53: rrereRrerr . rRrerrerrRre % iiiIIii1IIi % rRrer % IiII
def RrreRrRrererRRrer ( data ) :
 rreRrRrRRrRrrer = iiIii ( RrRRRRR , data + '####' , '####' )
 return rreRrRrRRrRrrer
 if 20 - 20: RrrrererRrrerer / iiiIIii1IIi
def iIrrrrerr ( ) :
 RRr = RrrRreRRrreRRrrerreRreR ( )
 IIiI1i ( 'search/search.php?q=' + RRr )
 if 6 - 6: I11i / rrRrRrer - iII111i
def IIiI1i ( url ) :
 i1i ( )
 if 62 - 62: IiII % iII111i
 RRrrereRRrereRr = url . rfind ( '/' )
 I1I1I11Ii = url [ RRrrereRRrereRr + 1 : ]
 if 'search' not in I1I1I11Ii :
  ii1Iii1 = '<center><div class="content-box">'
  rreRRRRRreR = int ( I1I1I11Ii ) + 1
  if I1I1I11Ii > 1 :
   I1I1IiIi1 = url . replace ( '/' + str ( I1I1I11Ii ) , '/' + str ( rreRRRRRreR ) )
 else :
  ii1Iii1 = 'Search Results For: "<font'
  I1I1IiIi1 = url + '/2'
  if 58 - 58: rRrer - rrRrRrer - iII111iiiii11
 I111iIi1 = RrerRr ( url )
 I111iIi1 = iiIii ( I111iIi1 , ii1Iii1 , '<div class="footer-box">' )
 I111iIi1 = rrrereRrererRrererer ( I111iIi1 )
 iiI111I1iIiI = II ( I111iIi1 , '<td width="20%"' , 'alt="' )
 rrere = 0
 for RrrerrRrrer in iiI111I1iIiI :
  rrerererrrrRrer = iiIii ( RrrerrRrrer , '<a href="' , '"' )
  if 38 - 38: RRreRRreRreRre - rrereRrerr % rRrerrerrRre
  rrRRrrrrrr = iiIii ( RrrerrRrrer , 'title="' , '"' )
  rrRRrrrrrr = rrRRrrrrrr . encode ( 'utf-8' )
  iI1i11 = iiIii ( RrrerrRrrer , '<img src="' , '"' )
  IiI1 ( rrRRrrrrrr , rrerererrrrRrer , 710 , iI1i11 , isFolder = True )
  rrere = rrere + 1
  if 64 - 64: iiiIIii1IIi
 if rrere == 25 :
  IiI1 ( '[B][COLOR white]Next Page[/COLOR][/B]' , I1I1IiIi1 , 700 , 'http://i.imgur.com/ajZJyfj.png' )
  if 15 - 15: I11i + iII111i / I11i / rRrerrerrRre
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 31 - 31: IIII + RRreRRreRreRre + IIII . iiiIIii1IIi + IiIIi1I1Iiii / RRrrRRr
 if 6 - 6: IiIIi1I1Iiii % rrereRrerr * IiII / IIiIiII11i + IiIIi1I1Iiii
def IIiI11i11 ( url ) :
 I111iIi1 = RrereRrerRRrereRrere ( url )
 iI1i11 = iiIii ( I111iIi1 , '<meta property="og:image" content="' , '"' )
 I111iIi1 = iiIii ( I111iIi1 , 'Alternative Versions</h2>' , 'Write a comment:' )
 i1i ( )
 i1 = 0
 iiI111I1iIiI = II ( I111iIi1 , '<td class="entry">' , '<td class="entry2"' )
 for RrrerrRrrer in iiI111I1iIiI :
  rrerererrrrRrer = iiIii ( RrrerrRrrer , 'href="' , '"' )
  rrRRrrrrrr = iiIii ( RrrerrRrrer , '</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' , '</td>' )
  rrRRrrrrrr = rrRRrrrrrr . encode ( 'utf-8' )
  if rrRRrrrrrr <> ' Thevideos' :
   i1 = i1 + 1
   IiI1 ( '[COLOR yellow]' + str ( i1 ) + ':[/COLOR] [COLOR white]' + rrRRrrrrrr + '[/COLOR]' , rrerererrrrRrer , 3 , iI1i11 , isFolder = False )
   if 14 - 14: RrreRrr
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 73 - 73: IIII + Ii1I . RrrrererRrrerer
 if 46 - 46: RrrrererRrrerer - RRrrRRr / rRrer - iII111iiiii11 + Ii1I
def rrrereRrererRrererer ( data ) :
 data = data . replace ( '\r' , '' ) . replace ( '\n' , '' ) . replace ( '\t' , '' ) . replace ( '&nbsp;' , '' ) . replace ( '[' , '' ) . replace ( ']' , '' )
 return data
 if 58 - 58: RRrrRRr / RRrrRRr + IIII + IiII - rRrer . iII111i
 if 15 - 15: IIII * rRrer % rrereRrerr . rRrer . IiII
def rrerrRreRRR ( url ) :
 rrerrrerereRrRrrre = RrereRrerRRrereRrere ( url )
 rrerrrerereRrRrrre = iiIii ( rrerrrerereRrRrrre , '<div class="tv_letter_nav"><ul>' , '<div class="tv_all">' )
 rrerrrerereRrRrrre = rrrereRrererRrererer ( rrerrrerereRrRrrre )
 RrereRRRrRrrreR = re . compile ( "<a href=/(.+?)>(.+?)</a>" , re . DOTALL ) . findall ( str ( rrerrrerereRrRrrre ) )
 if 81 - 81: RRreRRreRreRre / rrereRrerr - iiiIIii1IIi / iIiiiI1IiI1I1
 i1i ( )
 for url , rRrRrerrereRRre in RrereRRRrRrrreR :
  rRrRrerrereRRre = rrRrererererrereR ( rRrRrerrereRRre )
  rrR = rRrRrerrereRRre [ : 1 ] . upper ( )
  IiI1 ( rRrRrerrereRRre , url , 83 , "http://icons.iconarchive.com/icons/hydrattz/multipurpose-alphabet/256/Letter-" + rrR + "-blue-icon.png" )
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 16 - 16: iIiiiI1IiI1I1 % rRrer % I1Ii111
 if 87 - 87: iiiIIii1IIi . iII111iiiii11 * rRrer
def RRRr ( url ) :
 rrerrRrrereR = RrereRrerRRrereRrere ( RrreRrRrererRRrer ( 'TV1' ) + url )
 rrerrRrrereR = iiIii ( rrerrRrrereR , '<a href="/tv-listings/0-9">0-9</a>' , '<div class="home">' )
 rrerrRrrereR = rrrereRrererRrererer ( rrerrRrrereR )
 RrereRRRrRrrreR = re . compile ( '<a href="/(.+?)">(.+?)</a>' , re . DOTALL ) . findall ( str ( rrerrRrrereR ) )
 i1i ( )
 IiI1 ( "Number 0-9" , "tv-listings/0-9" , 83 , RrRrerere )
 for url , rRrRrerrereRRre in RrereRRRrRrrreR :
  rRrRrerrereRRre = rrRrererererrereR ( rRrRrerrereRRre )
  rrR = rRrRrerrereRRre [ : 1 ] . upper ( )
  IiI1 ( rRrRrerrereRRre , url , 83 , "http://icons.iconarchive.com/icons/hydrattz/multipurpose-alphabet/256/Letter-" + rrR + "-blue-icon.png" )
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 38 - 38: iiiIIii1IIi + RrreRrr * RrrrererRrrerer * IIII % iII111i
def I1I11IiiI ( name , url ) :
 I1IiI1iI11 = RrereRrerRRrereRrere ( RrreRrRrererRRrer ( 'TV1' ) + url )
 I1IiI1iI11 = iiIii ( I1IiI1iI11 , '<div class="home">' , '</div>' )
 I1IiI1iI11 = rrrereRrererRrererer ( I1IiI1iI11 )
 RrereRRRrRrrreR = re . compile ( '<a href="/(.+?)">(.+?)</a>' , re . DOTALL ) . findall ( I1IiI1iI11 )
 iIi = xbmcgui . DialogProgress ( )
 if 29 - 29: RRreRRreRreRre . rRrerrerrRre
 RRrerrerRreRrererer = len ( RrereRRRrRrrreR )
 I1iI11iii = 0
 iIi . create ( 'UPDATING REAPER' )
 if 78 - 78: RRreRRreRreRre / iIiiiI1IiI1I1 * RrrrererRrrerer
 i1i ( )
 for url , name in RrereRRRrRrrreR :
  IiI1 ( name , url , 84 , RrRrerere )
  I1iI11iii = I1iI11iii + 1
  IiIi1iI11 = ( I1iI11iii * 100 ) / RRrerrerRreRrererer
  iIi . update ( IiIi1iI11 )
 iIi . update ( 100 )
 iIi . close ( )
 if 11 - 11: I11i
 xbmcplugin . addSortMethod ( handle = int ( sys . argv [ 1 ] ) , sortMethod = xbmcplugin . SORT_METHOD_LABEL )
 if 26 - 26: iiiIIii1IIi * rRrerrerrRre - iII111i
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 27 - 27: I11i * rRrerrerrRre - RrrrererRrrerer + I1Ii111 * I1Ii111
def rreRRreRreRRrerRre ( name , url ) :
 rrerRrerrrererereRR = RrereRrerRRrereRrere ( RrreRrRrererRRrer ( 'TV1' ) + url )
 rrerRrerrrererereRR = iiIii ( rrerRrerrrererereRR , 'target="_blank">IMDB</a><br/>' , '<div class="addthis">' )
 rrerRrerrrererereRR = rrrereRrererRrererer ( rrerRrerrrererereRR )
 RrereRRRrRrrreR = re . compile ( "<h3><a href='/(.+?)'>(.+?)</a></h3>" , re . DOTALL ) . findall ( str ( rrerRrerrrererereRR ) )
 i1i ( )
 for url , name in RrereRRRrRrrreR :
  IiI1 ( name , url , 85 , RrRrerere )
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 9 - 9: Ii1I % RrreRrr / IiIIi1I1Iiii
def IIIiI1ii1IIi ( name , url ) :
 rreRrerrrer = RrereRrerRRrereRrere ( RrreRrRrererRRrer ( 'TV1' ) + url )
 rreRrerrrer = iiIii ( rreRrerrrer , 'target="_blank">IMDB</a><br/>' , '<div class="addthis">' )
 rreRrerrrer = rrrereRrererRrererer ( rreRrerrrer )
 RrereRRRrRrrreR = re . compile ( "<a href='/(.+?)'><strong>(.+?)</strong>(.+?)</a></li><li>" , re . DOTALL ) . findall ( str ( rreRrerrrer ) )
 i1i ( )
 for url , II11iI1iiI , name in RrereRRRrRrrreR :
  IiI1 ( name , url , 81 , RrRrerere )
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 48 - 48: IiII . iII111iiiii11 . IIiIiII11i . rRrer % I11i / rrRrRrer
def I1I1I1IIi1III ( name , url , iconimage ) :
 ii1I111i1Ii = 'False'
 iIIii = True
 try : addon . resolve_url ( streamlink )
 except : pass
 RreRrrr = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 RreRrrr . setInfo ( 'Video' , infoLabels = { "Title" : name } )
 RRRRrr = [ ]
 if ii1I111i1Ii == 'true' :
  RRRRrr = [ ]
  RRRRrr . append ( ( 'Download' , 'XBMC.RunPlugin(%s?mode=9&name=%s&url=%s)' % ( sys . argv [ 0 ] , name , urllib . quote_plus ( url ) ) ) )
  RreRrrr . addContextMenuItems ( RRRRrr , replaceItems = True )
  if 84 - 84: I11i % iiiIIii1IIi + RrrrererRrrerer . I11i % RrrrererRrrerer
 RreRrrr . addContextMenuItems ( RRRRrr , replaceItems = True )
 iIIii = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = url , listitem = RreRrrr , isFolder = False )
 return iIIii
 if 93 - 93: RRreRRreRreRre
 if 85 - 85: RrreRrr % RrreRrr + RRreRRreRreRre / iII111i
def II11IiiIII ( typeq , title , message , times , line2 = '' , line3 = '' ) :
 if typeq == 'small' :
  rrererRRRreRrr = "http://i.imgur.com/x7IbgCV.png"
  xbmc . executebuiltin ( "XBMC.Notification(" + title + "," + message + "," '' "," + rrererRRRreRrr + ")" )
 elif typeq == 'big' :
  Rr = xbmcgui . Dialog ( )
  Rr . ok ( ' ' + title + ' ' , ' ' + message + ' ' , line2 , line3 )
 else :
  Rr = xbmcgui . Dialog ( )
  Rr . ok ( ' ' + title + ' ' , ' ' + message + ' ' )
  if 50 - 50: I1Ii111 - RrreRrr + iiiIIii1IIi / RRreRRreRreRre - I1Ii111 + RRrrRRr
def i1I11iIiII ( url ) :
 II1I1I1Ii = urllib2 . Request ( url )
 II1I1I1Ii . add_header ( 'User-Agent' , "Magic Browser" )
 i1rRreRRre = urllib2 . urlopen ( II1I1I1Ii )
 RRrerrerRRRreR = i1rRreRRre . read ( )
 i1rRreRRre . close ( )
 return RRrerrerRRRreR
 if 22 - 22: iIiiiI1IiI1I1 - I1Ii111 / IIII % iII111iiiii11 + iII111i
def rrRrererererrereR ( name ) :
 name = name . replace ( '&amp;' , '&' )
 name = name . replace ( '&#x27;' , "'" )
 urllib . quote ( u'\xe9' . encode ( 'UTF-8' ) )
 name = name . replace ( u'\xe9' , 'e' )
 urllib . quote ( u'\xfa' . encode ( 'UTF-8' ) )
 name = name . replace ( u'\xfa' , 'u' )
 urllib . quote ( u'\xed' . encode ( 'UTF-8' ) )
 name = name . replace ( u'\xed' , 'i' )
 urllib . quote ( u'\xe4' . encode ( 'UTF-8' ) )
 name = name . replace ( u'\xe4' , 'a' )
 urllib . quote ( u'\xf4' . encode ( 'UTF-8' ) )
 name = name . replace ( u'\xf4' , 'o' )
 urllib . quote ( u'\u2013' . encode ( 'UTF-8' ) )
 name = name . replace ( u'\u2013' , '-' )
 urllib . quote ( u'\xe0' . encode ( 'UTF-8' ) )
 name = name . replace ( u'\xe0' , 'a' )
 try : name = messupText ( name , True , True )
 except : pass
 try : name = name . decode ( 'UTF-8' ) . encode ( 'UTF-8' , 'ignore' )
 except : pass
 name = name . replace ( '\u00a0' , ' ' ) . replace ( '\u00ae' , '' ) . replace ( '\u00e9' , '' ) . replace ( '\u00e0' , '' ) . replace ( '\u2013' , '' ) . replace ( '\u00e7' , '' ) . replace ( '\u00f1' , '' ) . replace ( "&amp;" , "&" ) . replace ( '&quot;' , '"' ) . replace ( '<a href="' , '' ) . replace ( '</a>&#8220;#' , '"' )
 name = name . replace ( '&lt;' , '<' ) . replace ( '&gt;' , '>' ) . replace ( '<name>' , '<title>' ) . replace ( '</name>' , '</title>' ) . replace ( '</p>' , '\r\n' ) . replace ( '&nbsp;' , '' ) . replace ( '&#8221;' , '"' ) . replace ( '&#8243;' , '"' ) . replace ( '<!-- EVO LINK' , '\n' ) . replace ( 'END EVO -->' , '' ) . replace ( '<p>' , '' ) . replace ( '&#038;' , '&' ) . replace ( '&#8211;' , '--' ) . replace ( '<br />' , '' ) . replace ( '&#215;' , 'x' ) . replace ( '&#039;' , "'" )
 if 5 - 5: RrrrererRrrerer / rrRrRrer + RrreRrr % IiII
 return name
 if 93 - 93: rRrer % iiiIIii1IIi
def Rrrrerrerrre ( url ) :
 rRRre = [ ]
 list = common . plx2list ( url )
 Ii1iI111 = list [ 0 ] [ "background" ]
 for IIi1i1IiIIi1i in list [ 1 : ] :
  iI1i11 = "" if not IIi1i1IiIIi1i . has_key ( "thumb" ) else common . GetEncodeString ( IIi1i1IiIIi1i [ "thumb" ] )
  rRrRrerrereRRre = common . GetEncodeString ( IIi1i1IiIIi1i [ "name" ] )
  if IIi1i1IiIIi1i [ "type" ] == 'playlist' :
   IiI1 ( "[COLOR blue][{0}][/COLOR]" . format ( rRrRrerrereRRre ) , IIi1i1IiIIi1i [ "url" ] , 1 , iI1i11 , background = Ii1iI111 )
  else :
   IiI1 ( rRrRrerrereRRre , IIi1i1IiIIi1i [ "url" ] , 3 , iI1i11 , isFolder = False , background = Ii1iI111 )
   rRRre . append ( { "url" : IIi1i1IiIIi1i [ "url" ] , "image" : iI1i11 , "name" : rRrRrerrereRRre . decode ( "utf-8" ) } )
   if 15 - 15: IiIIi1I1Iiii + IiII . IIII - iiiIIii1IIi / RRreRRreRreRre % iiiIIii1IIi
 common . SaveList ( rR , rRRre )
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 86 - 86: IIiIiII11i / Ii1I * I1Ii111
 if 64 - 64: IIII / RRreRRreRreRre * rRrer * IIII
def i11iiiiI1i ( name , url , mode , iconimage , fanart , description = '' ) :
 rrr = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&description=" + str ( description ) + "&fanart=" + urllib . quote_plus ( fanart )
 iIIii = True
 RreRrrr = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 RreRrrr . setProperty ( 'fanart_image' , fanart )
 if not "mtester" in url . lower ( ) :
  RreRrrr . setProperty ( "IsPlayable" , "true" )
 iIIii = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = rrr , listitem = RreRrrr , isFolder = False )
 return iIIii
 if 60 - 60: IiII / I1IiiI % I11i / I11i * I11i . RrreRrr
def IiI1 ( name , url , mode , iconimage , description = '' , isFolder = True , background = None ) :
 if 99 - 99: rRrer
 if '^' in url :
  rRrereRrRr = name
  RrRi111i , url = url . split ( '^' )
  name = '[COLOR gold]' + rRrereRrRr + ' - ' + RrRi111i + '[/COLOR]'
  if 46 - 46: RrrrererRrrerer * IiIIi1I1Iiii % Ii1I + RRreRRreRreRre * rrereRrerr
 rrr = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&description=" + urllib . quote_plus ( description )
 if 34 - 34: RrrrererRrrerer
 if background == None :
  background = iconimage
  if 27 - 27: I1Ii111 - RRreRRreRreRre % IiII * rRrerrerrRre . rrereRrerr % iiiIIii1IIi
 RreRrrr = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage )
 RreRrrr . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description } )
 RreRrrr . setProperty ( 'fanart_image' , background )
 if mode == 1 or mode == 2 :
  RreRrrr . addContextMenuItems ( items = [ ( '{0}' . format ( rRrRrrererRr ( 10008 ) . encode ( 'utf-8' ) ) , 'XBMC.RunPlugin({0}?url={1}&mode=22)' . format ( sys . argv [ 0 ] , urllib . quote_plus ( url ) ) ) ] )
 elif mode == 3 :
  RreRrrr . setProperty ( 'IsPlayable' , 'true' )
  RreRrrr . addContextMenuItems ( items = [ ( '{0}' . format ( rRrRrrererRr ( 10009 ) . encode ( 'utf-8' ) ) , 'XBMC.RunPlugin({0}?url={1}&mode=31&iconimage={2}&name={3})' . format ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , iconimage , name ) ) ] )
 elif mode == 32 :
  RreRrrr . setProperty ( 'IsPlayable' , 'true' )
  RreRrrr . addContextMenuItems ( items = [ ( '{0}' . format ( rRrRrrererRr ( 10010 ) . encode ( 'utf-8' ) ) , 'XBMC.RunPlugin({0}?url={1}&mode=33&iconimage={2}&name={3})' . format ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , iconimage , name ) ) ] )
 elif mode == 60 :
  url = "https://www.youtube.com/watch?v=" + url
  rrr = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&description=" + urllib . quote_plus ( description )
  RreRrrr . setProperty ( 'IsPlayable' , 'true' )
 xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = rrr , listitem = RreRrrr , isFolder = isFolder )
 if 37 - 37: iII111iiiii11 + RRreRRreRreRre - I1IiiI % IIII
def i1I1i1i ( title = "" , defaultText = "" ) :
 iII1 = xbmc . Keyboard ( defaultText , title )
 iII1 . doModal ( )
 iiiIIIi11I = "" if not iII1 . isConfirmed ( ) else iII1 . getText ( )
 return iiiIIIi11I
 if 30 - 30: rRrerrerrRre % rRrerrerrRre % rrereRrerr . rRrer
def I1ii1IIi1IiII ( title , list ) :
 Rr = xbmcgui . Dialog ( )
 rreIIIIiI11I = Rr . select ( title , list )
 return rreIIIIiI11I
 if 31 - 31: I1Ii111
def i11iIIi ( url , iconimage , name ) :
 RrerereR = common . ReadList ( RRrRreRrererre )
 for rrreRRr in RrerereR :
  if rrreRRr [ "url" ] . lower ( ) == url . lower ( ) :
   xbmc . executebuiltin ( "Notification({0}, '{1}' {2}, 5000, {3})" . format ( IIIII , name , rRrRrrererRr ( 10011 ) . encode ( 'utf-8' ) , I1I ) )
   return
   if 16 - 16: IIiIiII11i . iiiIIii1IIi
 list = common . ReadList ( rR )
 for IIi1i1IiIIi1i in list :
  if IIi1i1IiIIi1i [ "name" ] . lower ( ) == name . lower ( ) :
   url = IIi1i1IiIIi1i [ "url" ]
   iconimage = IIi1i1IiIIi1i [ "image" ]
   break
   if 27 - 27: RrreRrr - IIiIiII11i
 if not iconimage :
  iconimage = ""
  if 35 - 35: iII111iiiii11 - rRrerrerrRre / RrrrererRrrerer
 iI111I11i = { "url" : url , "image" : iconimage , "name" : name . decode ( "utf-8" ) }
 if 50 - 50: rRrer
 RrerereR . append ( iI111I11i )
 common . SaveList ( RRrRreRrererre , RrerereR )
 xbmc . executebuiltin ( "Notification({0}, '{1}' {2}, 5000, {3})" . format ( IIIII , name , rRrRrrererRr ( 10012 ) . encode ( 'utf-8' ) , I1I ) )
 if 33 - 33: IiII
def rRrrereRrRreR ( ) :
 if 69 - 69: iiiIIii1IIi * IIiIiII11i - rrRrRrer + RRreRRreRreRre + RRreRRreRreRre
 iIi = xbmcgui . DialogProgress ( )
 iIi . create ( 'REAPER Logging in to Freeview Server' )
 Rrerr ( )
 rrRrrRrereRr = xbmcgui . Window ( 10000 ) . getProperty ( "session_id" )
 rrrreR = "%s%s%s" % ( RRRrRreRrer , '/tv/api/groups?session_key=' , ( rrRrrRrereRr ) )
 RRrerrerRRRreR = rrRrerer ( rrrreR )
 rrerrereRrerRrrRre = II ( RRrerrerRRRreR , '{' , '_count' )
 for rrerRreRRrererrRR in rrerrereRrerRrrRre :
  IiIIiii11II1 = iiIii ( rrerRreRRrererrRR , 'channels":' , ',"channels' ) . replace ( '[' , '' ) . replace ( ']' , '' ) . replace ( '"' , '' )
  rRrRrerrereRRre = iiIii ( rrerRreRRrererrRR , 'title":"' , '",' )
  iI1i11 = iiIii ( rrerRreRRrererrRR , 'logo_148x148_uri":"' , '",' ) . replace ( '\\' , '' )
  rrrreR = iiIii ( rrerRreRRrererrRR , 'group_id":"' , '",' )
  IiI1 ( '[COLOR gold]' + rRrRrerrereRRre + '[/COLOR]' , rrrreR , 310 , iI1i11 , IiIIiii11II1 , isFolder = True )
  if 42 - 42: I1IiiI % iIiiiI1IiI1I1 . IIII
 iIi . close ( )
 II1II1iI ( )
 if 58 - 58: RRreRRreRreRre . rrereRrerr / iII111iiiii11 . RrrrererRrrerer / IiIIi1I1Iiii * iIiiiI1IiI1I1
 if 53 - 53: I1Ii111 - RRreRRreRreRre / RRrrRRr % rrRrRrer * IIiIiII11i % iII111i
def rrerRRRRre ( name , url , description ) :
 ii1I = description
 rrRRrrrrrr = ''
 RRrerRrrere = [ ]
 rrRrrRrereRr = xbmcgui . Window ( 10000 ) . getProperty ( "session_id" )
 url = "%s%s%s%s%s" % ( RRRrRreRrer , 'api/group/' , url , '?session_key=' , rrRrrRrereRr )
 RRrerrerRRRreR = i11I1I ( url ) . translate ( rrereR )
 RRrerrerRRRreR = rrrerrrrrrerer ( RRrerrerRRRreR )
 if 78 - 78: iiiIIii1IIi . RRrrRRr % iiiIIii1IIi . RRreRRreRreRre / iII111i
 iI111I11i = json . loads ( RRrerrerRRRreR )
 ii1I = iI111I11i [ 'channels' ]
 for i1 in ii1I :
  RrrerRrrerereRrRre = i1 [ 'id' ]
  rrRRrrrrrr = i1 [ 'title' ]
  description = i1 [ 'description' ]
  RRrerRrrere . append ( rrRRrrrrrr )
  if 25 - 25: I11i . I1IiiI . iIiiiI1IiI1I1 / rRrerrerrRre
  I1I = 'http://static.filmon.com/couch/channels/%s/extra_big_logo.png' % RrrerRrrerereRrRre
  IiI1 ( '[COLOR gold]' + rrRRrrrrrr + '[/COLOR]' , str ( RrrerRrrerereRrRre ) , 320 , I1I , isFolder = False )
  if 54 - 54: I1IiiI . IiII - I11i + IIII + IiIIi1I1Iiii / IiIIi1I1Iiii
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 22 - 22: IIII . iiiIIii1IIi
def i1IiiiiIi1I ( name , url , iconimage ) :
 rrrreRrerreRrRR = name
 iIi = xbmcgui . DialogProgress ( )
 iIi . create ( 'Opening ' + name . upper ( ) )
 rrRrrRrereRr = xbmcgui . Window ( 10000 ) . getProperty ( "session_id" )
 url = "%s%s%s%s%s" % ( RRRrRreRrer , 'api/channel/' , url , '?session_key=' , rrRrrRrereRr )
 iIi11i = datetime . datetime . now ( )
 rrerrererreRr = name . upper ( )
 try :
  RRrerrerRRRreR = rrRrerer ( url )
 except :
  return
 RRRRRrrRRrr = name
 i1I1iIii11 = ""
 if 80 - 80: rRrer - iIiiiI1IiI1I1
 if 35 - 35: IIII - RrrrererRrrerer . IiIIi1I1Iiii * IiIIi1I1Iiii / RrreRrr + I11i
 rRrreRrreRreR = 1
 III1II1i = re . compile ( '"id":(.+?),"quality":"high","url":"(.+?)","name":"(.+?)","is_adaptive":"(.+?)","watch-timeout":(.+?)}' ) . findall ( RRrerrerRRRreR )
 if len ( III1II1i ) < 1 :
  III1II1i = re . compile ( '"id":(.+?),"quality":"low","url":"(.+?)","name":"(.+?)","is_adaptive":"(.+?)","watch-timeout":(.+?)}' ) . findall ( RRrerrerRRRreR )
  if 3 - 3: rrRrRrer
 if len ( III1II1i ) < 1 :
  rRrreRrreRreR = 2
  III1II1i = re . compile ( '"id":(.+?),"quality":"high","url":"(.+?)""name":"(.+?)","is_adaptive":(.+?),"watch-timeout":"(.+?)"}' ) . findall ( RRrerrerRRRreR )
 if len ( III1II1i ) < 1 :
  rRrreRrreRreR = 2
  III1II1i = re . compile ( '"id":(.+?),"quality":"low","url":"(.+?)","name":"(.+?)","is_adaptive":(.+?),"watch-timeout":(.+?)}' ) . findall ( RRrerrerRRRreR )
  if 35 - 35: rrereRrerr . RRreRRreRreRre + IiIIi1I1Iiii + iII111i + I1IiiI
 if len ( III1II1i ) < 1 :
  return
 RrrRrrRreRrerre = ''
 if 59 - 59: IiIIi1I1Iiii + rrRrRrer - iII111i . RRrrRRr + IIiIiII11i % Ii1I
 if rRrreRrreRreR == 1 :
  for id , url , name , i111Iii , rrerre in III1II1i :
   url = url . replace ( "\/" , "/" )
   name = name
   id = id
   if name . endswith ( 'm4v' ) :
    RrrRrrRreRrerre = 'vodlast'
   else :
    RrrRrrRreRrerre = 'live/?id=' + url . split ( '=' ) [ 1 ]
  i1iIi1IIiIII1 = iiIii ( url , 'rtmp://' , '/' )
  i1Ii11I1II = str ( url ) + ' playpath=' + name + ' app=' + RrrRrrRreRrerre + ' swfUrl=http://www.filmon.com/tv/modules/FilmOnTV/files/flashapp/filmon/FilmonPlayer.swf' + ' tcUrl=' + url + ' pageUrl=http://www.filmon.com/' + ' live=1 timeout=45 swfVfy=1'
 else :
  for id , url , name , i111Iii , rrerre in III1II1i :
   url = url . replace ( "\/" , "/" )
  i1iIi1IIiIII1 = iiIii ( url , 'rtmp://' , '/' )
  i1Ii11I1II = str ( url ) + '/' + str ( name )
 iIi . update ( 75 )
 rRRRrrrer = xbmc . PlayList ( 1 )
 rRRRrrrer . clear ( )
 iiiI1IiIIii = xbmcgui . ListItem ( rrrreRrerreRrRR , iconImage = iconimage , thumbnailImage = iconimage )
 iiiI1IiIIii . setInfo ( "Video" , { "Title" : rrrreRrerreRrRR } )
 iiiI1IiIIii . setProperty ( 'mimetype' , 'video/x-msvideo' )
 iiiI1IiIIii . setProperty ( 'IsPlayable' , 'true' )
 rRRRrrrer . add ( i1Ii11I1II , iiiI1IiIIii )
 IIIIiii = xbmc . Player ( xbmc . PLAYER_CORE_AUTO )
 IIIIiii . play ( rRRRrrrer )
 if 26 - 26: iII111iiiii11 - IIII * RrreRrr + RRreRRreRreRre * Ii1I
 iIi . close ( )
 if 87 - 87: IiIIi1I1Iiii + RRreRRreRreRre - IiII * iiiIIii1IIi . rRrerrerrRre % RRrrRRr
 if 83 - 83: iIiiiI1IiI1I1 * I1IiiI * rrRrRrer . I11i / IiII + I1IiiI
def rrRrerer ( url ) :
 II1I1I1Ii = urllib2 . Request ( url )
 II1I1I1Ii . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 i1rRreRRre = urllib2 . urlopen ( II1I1I1Ii )
 RRrerrerRRRreR = i1rRreRRre . read ( )
 i1rRreRRre . close ( )
 return RRrerrerRRRreR
 if 43 - 43: iII111iiiii11
def i11I1I ( url ) :
 rRRRre = { }
 rRRRre [ 'Accept' ] = 'application/json, text/javascript, */*; q=0.01'
 rRRRre [ 'User-Agent' ] = 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
 II1I1I1Ii = I11ii1 . http_GET ( url , headers = rRRRre ) . content
 return II1I1I1Ii
 if 32 - 32: IIII % rRrerrerrRre * IiIIi1I1Iiii
def Rrerr ( ) :
 try :
  rrRrrRrereRr = xbmcgui . Window ( 10000 ) . getProperty ( "session_id" )
  rrrreR = "%s%s%s" % ( RRRrRreRrer , '/tv/api/groups?session_key=' , ( rrRrrRrereRr ) )
  RRrerrerRRRreR = rrRrerer ( rrrreR )
 except :
  xbmcgui . Window ( 10000 ) . setProperty ( "session_id" , '' )
 if not xbmcgui . Window ( 10000 ) . getProperty ( "session_id" ) :
  RRrerrerRRRreR = rrRrerer ( RrerreRrr )
  RrereRRRrRrrreR = re . compile ( '"session_key":"(.+?)"' ) . findall ( RRrerrerRRRreR )
  rrRrrRrereRr = RrereRRRrRrrreR [ 0 ]
  print "FilmOn.TV......Not logged in"
  xbmcgui . Window ( 10000 ) . setProperty ( "session_id" , rrRrrRrereRr )
  RreRrerererRrreR ( )
  if 82 - 82: rrereRrerr
  if 86 - 86: IiIIi1I1Iiii * iIiiiI1IiI1I1 * RRreRRreRreRre
  if 83 - 83: rrereRrerr / rRrerrerrRre
def RreRrerererRrreR ( ) :
 RRrrerereRRrerere = xbmcgui . getCurrentWindowId ( )
 rrRrrRrereRr = xbmcgui . Window ( 10000 ) . getProperty ( "session_id" )
 rrrreR = "http://www.filmon.com/api/keep-alive?session_key=%s" % ( rrRrrRrereRr )
 i11I1I ( rrrreR )
 RRRRrereRrrR = Timer ( 60.0 , RreRrerererRrreR )
 RRRRrereRrrR . start ( )
 if 64 - 64: RrrrererRrrerer . IIiIiII11i - iII111iiiii11 . IIII - rrRrRrer
def RrerRrerrererer ( ) :
 i11i11II11i1 = xbmc . getInfoLabel ( 'Container.PluginName' )
 print 'InfoLabel ReaperAddon >>' + i11i11II11i1 + '<<>>' + i11i11II11i1 [ - 4 : ] + '<<Len>>' + str ( len ( i11i11II11i1 ) ) + '<<'
 if i11i11II11i1 [ - 2 : ] == 'US' or len ( i11i11II11i1 ) < 10 :
  return 0
 else :
  return 1
  if 17 - 17: iIiiiI1IiI1I1 + IiIIi1I1Iiii . rRrerrerrRre
def rrrerrrrrrerer ( link ) :
 iI111I11i = link . replace ( '\u00a0' , ' ' ) . replace ( '\u00ae' , '' ) . replace ( '\u00e9' , '' ) . replace ( '\u00e0' , '' ) . replace ( '\u2013' , '' ) . replace ( '\u00e7' , '' ) . replace ( '\u00f1' , '' ) . replace ( '@#039;' , "'" )
 if 12 - 12: rRrerrerrRre + iII111i + IiII . rrereRrerr / I1Ii111
 return iI111I11i
 if 29 - 29: rrereRrerr . IIII - iIiiiI1IiI1I1
def rrrrRre ( ) :
 if 37 - 37: RrreRrr + IIiIiII11i . iII111i % IiII % IiII
 quit ( )
 if 26 - 26: RRreRRreRreRre
def i111I1iiIiII ( ) :
 xbmcgui . Dialog ( ) . ok ( 'REAPER Support' , 'For reporting faults, suggestions, general support' , 'Facebook: Reaper Addon Support Group!' , 'Twitter: @reaperaddons' )
 if 97 - 97: iIiiiI1IiI1I1 - rRrerrerrRre - iiiIIii1IIi * IIiIiII11i
def RRRrereR ( ) :
 iIi = xbmcgui . DialogProgress ( )
 iIi . create ( 'REAPER IS NOW UPDATING' )
 iIi . update ( 0 )
 rrrRrerreRrerrrer = base64 . b64decode ( 'YUhSMGNEb3ZMeUZ5WldGd1pYSmhaR1J2Ym5NdUlYUnJMM1Z3SVdSaGRHVWhMblI0ZEE9PQ==' )
 RreRrrrI11iI1I = base64 . b64decode ( rrrRrerreRrerrrer )
 iII = RreRrrrI11iI1I . replace ( '!' , '' )
 Iii1iiIi1II1 = iII
 Rrrererer = RrereRrerRRrereRrere ( Iii1iiIi1II1 )
 if 69 - 69: I11i + rrRrRrer * RRreRRreRreRre . iII111i % rRrer
 if 'UPDATELIST' not in Rrrererer :
  return
  if 96 - 96: IIII . IIII - IiII / IiII
 rRRRR = II ( Rrrererer , 'I:' , '"#' )
 for RrrerrRrrer in rRRRR :
  iIi . update ( int ( iiIii ( RrrerrRrrer , 'I:"' , '"' ) ) )
  RrRriIIi11i1i1i1I = iiIii ( RrrerrRrrer , 'A:"' , '"' )
  i1i1iI1 = iiIii ( RrrerrRrrer , 'B:"' , '"' )
  rrrreR = iiIii ( RrrerrRrrer , 'C:"' , '"' )
  if 'addonDir' in RrRriIIi11i1i1i1I :
   rRRRrereRRRrRR = os . path . join ( rRRrererRR , i1i1iI1 )
   urllib . urlretrieve ( rrrreR , rRRRrereRRRrRR )
  elif 'libDir' in RrRriIIi11i1i1i1I :
   rRRRrereRRRrRR = os . path . join ( RrRr , i1i1iI1 )
   urllib . urlretrieve ( rrrreR , rRRRrereRRRrRR )
   if 23 - 23: rRrer . RRrrRRr - RrrrererRrrerer / rRrer * iiiIIii1IIi
   if 13 - 13: RRrrRRr * RrreRrr / RrreRrr . RrrrererRrrerer . iII111i . I11i
   if 26 - 26: RRrrRRr . iiiIIii1IIi
 xbmc . executebuiltin ( "UpdateLocalAddons" )
 xbmc . executebuiltin ( "UpdateAddonRepos" )
 iIi . update ( 100 )
 iIi . close ( )
 if 67 - 67: IiIIi1I1Iiii / RRreRRreRreRre
 xbmcgui . Dialog ( ) . ok ( 'REAPER IS NOW UPDATED' , 'A reboot may be required. ' , '' , 'Twitter @reaperaddons' )
 if 88 - 88: rRrer - iII111i
def rrerrreRrerRrrrR ( url ) :
 list = common . ReadList ( RRrRreRrererre )
 for IIi1i1IiIIi1i in list :
  if IIi1i1IiIIi1i [ "url" ] . lower ( ) == url . lower ( ) :
   list . remove ( IIi1i1IiIIi1i )
   break
   if 70 - 70: Ii1I * Ii1I + IiIIi1I1Iiii * iII111i % IIiIiII11i + iiiIIii1IIi
 common . SaveList ( RRrRreRrererre , list )
 xbmc . executebuiltin ( "XBMC.Container.Refresh()" )
 if 2 - 2: RrreRrr
def RRRR ( url ) :
 try :
  url = "PlayMedia(plugin://plugin.video.youtube/?action=play_video&videoid=" + url + ")"
  xbmc . executebuiltin ( url )
 except :
  xbmc . executebuiltin ( "XBMC.Notification(REAPER,This host is not supported or Video is broken::,10000)" )
  if 63 - 63: IIiIiII11i / rRrer + iII111iiiii11 . IiII . IIII
def IiI1iiI11 ( url ) :
 url = iiiIi + url
 list = rRrRRrrerrre ( url )
 i1i ( )
 for IIi1i1IiIIi1i in list :
  rRrRrerrereRRre = common . GetEncodeString ( IIi1i1IiIIi1i [ "display_name" ] )
  Ii1i1 = 46 if IIi1i1IiIIi1i [ "url" ] . find ( "youtube" ) > 0 else 3
  IiI1 ( rRrRrerrereRRre , IIi1i1IiIIi1i [ "url" ] , Ii1i1 , RrRrerere , isFolder = False )
  if 85 - 85: I11i - rRrer / I11i + iII111i - rrRrRrer
 xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 if 49 - 49: RrrrererRrrerer - RRreRRreRreRre / RrrrererRrrerer * rRrer + rRrerrerrRre
def Ii ( ) :
 IiI1 ( '[B][COLOR yellow]YOUR FAVOURITES LIST[/COLOR][/B]' , 'BLANK' , 999 , II11iiii1Ii )
 IiI1 ( "[COLOR yellow][B]{0}[/B][/COLOR]" . format ( rRrRrrererRr ( 10013 ) . encode ( 'utf-8' ) ) , "favorites" , 34 , os . path . join ( rRRrererRR , "resources" , "images" , "favstar.png" ) , isFolder = False )
 list = common . ReadList ( RRrRreRrererre )
 for IIi1i1IiIIi1i in list :
  rRrRrerrereRRre = IIi1i1IiIIi1i [ "name" ] . encode ( "utf-8" )
  iI1i11 = IIi1i1IiIIi1i [ "image" ] . encode ( "utf-8" )
  IiI1 ( rRrRrerrereRRre , IIi1i1IiIIi1i [ "url" ] , 32 , iI1i11 , isFolder = False )
 xbmc . executebuiltin ( 'Container.SetViewMode(50)' )
 if 20 - 20: I1IiiI / IIiIiII11i * Ii1I
 if 85 - 85: iIiiiI1IiI1I1 . IIII % iII111i % IiII
 if 80 - 80: Ii1I * IiII / iiiIIii1IIi % Ii1I / iiiIIii1IIi
def Iiii1 ( ) :
 i1iiIIiiiII = i1I1i1i ( "{0}" . format ( rRrRrrererRr ( 10014 ) . encode ( 'utf-8' ) ) ) . strip ( )
 if len ( i1iiIIiiiII ) < 1 :
  return
 Ii1I1 = i1I1i1i ( "{0}" . format ( rRrRrrererRr ( 10015 ) . encode ( 'utf-8' ) ) ) . strip ( )
 if len ( Ii1I1 ) < 1 :
  return
  if 71 - 71: rRrer + iiiIIii1IIi * Ii1I . rRrerrerrRre % RrreRrr % iiiIIii1IIi
 RrerereR = common . ReadList ( RRrRreRrererre )
 for rrreRRr in RrerereR :
  if rrreRRr [ "url" ] . lower ( ) == rrrreR . lower ( ) :
   xbmc . executebuiltin ( "Notification({0}, '{1}' {2}, 5000, {3})" . format ( IIIII , i1iiIIiiiII , rRrRrrererRr ( 10011 ) . encode ( 'utf-8' ) , I1I ) )
   return
   if 63 - 63: iII111iiiii11 * RrrrererRrrerer / IiII - Ii1I . iiiIIii1IIi + rrRrRrer
 iI111I11i = { "url" : Ii1I1 , "image" : "" , "name" : i1iiIIiiiII . decode ( "utf-8" ) }
 if 44 - 44: I1IiiI % IIiIiII11i % RRrrRRr
 RrerereR . append ( iI111I11i )
 if common . SaveList ( RRrRreRrererre , RrerereR ) :
  xbmc . executebuiltin ( "XBMC.Container.Update('plugin://{0}?mode=30&url=favorites')" . format ( rrererrrrRrerR ) )
  if 9 - 9: IiIIi1I1Iiii % iII111iiiii11 - I1Ii111
def iIII11Iiii1 ( name , url , iconimage = None ) :
 iiiI1IiIIii = xbmcgui . ListItem ( path = url , thumbnailImage = iconimage )
 iiiI1IiIIii . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
 xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , iiiI1IiIIii )
 if 95 - 95: IIiIiII11i
def rreRrRreRRrRreRrre ( name , url , iconimage ) :
 if 91 - 91: iIiiiI1IiI1I1
 url = 'http://thevideos.tv/embed-fbe9k99w2y6m-728x410.html'
 if 53 - 53: RrrrererRrrerer % RRrrRRr / iII111i % rrereRrerr % RrrrererRrrerer % iII111iiiii11
 import urlresolver , random , liveresolver
 if urlresolver . HostedMediaFile ( url ) . valid_url ( ) : RrrererreRRreRrerer = urlresolver . HostedMediaFile ( url ) . resolve ( )
 elif liveresolver . isValid ( url ) == True : RrrererreRRreRrerer = liveresolver . resolve ( url )
 else : RrrererreRRreRrerer = url
 RreRrrr = xbmcgui . ListItem ( name , iconImage = 'DefaultVideo.png' , thumbnailImage = iconimage )
 RreRrrr . setPath ( RrrererreRRreRrerer )
 if not "mtester" in url . lower ( ) :
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , RreRrrr )
 else :
  IIiIiI1I = "RunPlugin(" + url + ")"
  xbmc . executebuiltin ( IIiIiI1I )
  if 31 - 31: IIiIiII11i
  if 73 - 73: IIII . RRreRRreRreRre / RRrrRRr - iII111iiiii11 % RrreRrr
  if 80 - 80: I1Ii111 / IIII % RRreRRreRreRre . IiIIi1I1Iiii
  if 63 - 63: iII111i . iIiiiI1IiI1I1 . IiII
  if 46 - 46: IIII % rrereRrerr - RRrrRRr - IiIIi1I1Iiii - I1Ii111 / IiII
  if 68 - 68: I1IiiI - I11i / IiIIi1I1Iiii % IiII . rrRrRrer
  if 9 - 9: rrereRrerr
  if 48 - 48: RRrrRRr + RRrrRRr - IiIIi1I1Iiii
  if 27 - 27: RrrrererRrrerer + rRrer * IIII
  if 83 - 83: iiiIIii1IIi
  if 72 - 72: IiII
  if 87 - 87: I1IiiI
  if 48 - 48: IiIIi1I1Iiii * Ii1I * iiiIIii1IIi + RrreRrr - iII111iiiii11
  if 38 - 38: rRrer / iiiIIii1IIi % RrreRrr - rrereRrerr * rrRrRrer / rRrer
  if 13 - 13: RrrrererRrrerer * I11i - rRrerrerrRre
  if 79 - 79: Ii1I % RRrrRRr % rRrer
  if 45 - 45: IIiIiII11i * iII111i % RrrrererRrrerer
  if 24 - 24: IIII - IiII * Ii1I
  if 87 - 87: I1Ii111 - I11i % I11i . Ii1I / I11i
  if 6 - 6: rRrer / iiiIIii1IIi * iII111iiiii11 * RrreRrr
  if 79 - 79: rrereRrerr % RrrrererRrrerer
def RrrerRR ( url , name , iconimage ) :
 if RrerRrerrererer ( ) == 1 :
  RreRrrr = xbmcgui . ListItem ( name , iconImage = iconimage )
  RreRrrr . setInfo ( type = 'Video' , infoLabels = { 'Title' : name } )
  RreRrrr . setProperty ( "IsPlayable" , "true" )
  RreRrrr . setPath ( url )
  try :
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , RreRrrr )
  except :
   print 'ReaperAddon PlayFailed: ' + url
   pass
 else :
  print '****** ReaperAddon ResolveIT EQUALS Zero *******'
  if 86 - 86: iiiIIii1IIi / RRreRRreRreRre
def iiIii ( text , from_string , to_string , excluding = True ) :
 if excluding :
  try : IiIIiIIIiIii = re . search ( "(?i)" + from_string + "([\S\s]+?)" + to_string , text ) . group ( 1 )
  except : IiIIiIIIiIii = ''
 else :
  try : IiIIiIIIiIii = re . search ( "(?i)(" + from_string + "[\S\s]+?" + to_string + ")" , text ) . group ( 1 )
  except : IiIIiIIIiIii = ''
 return IiIIiIIIiIii
 if 17 - 17: iIiiiI1IiI1I1
def II ( text , start_with , end_with ) :
 IiIIiIIIiIii = re . findall ( "(?i)(" + start_with + "[\S\s]+?" + end_with + ")" , text )
 return IiIIiIIIiIii
 if 9 - 9: iII111iiiii11 + Ii1I
def I11I1II ( default = "" , heading = "" , hidden = False ) :
 iII1 = xbmc . Keyboard ( default , heading , hidden )
 if 33 - 33: RRreRRreRreRre
 iII1 . doModal ( )
 if ( iII1 . isConfirmed ( ) ) :
  return unicode ( iII1 . getText ( ) , "utf-8" )
 return default
 if 39 - 39: IIiIiII11i + IiIIi1I1Iiii
def II1II1iI ( ) :
 rreRR = xbmc . getSkinDir ( )
 if rreRR == 'skin.confluence' :
  xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 elif rreRR == 'skin.aeon.nox' :
  xbmc . executebuiltin ( 'Container.SetViewMode(511)' )
 else :
  xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
  if 76 - 76: RRreRRreRreRre . RrrrererRrrerer + rRrer
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 41 - 41: iIiiiI1IiI1I1 * IIII
 if 68 - 68: I1Ii111 - IIiIiII11i
def ii1I11II1 ( ) :
 xbmc . executebuiltin ( "Container.SetViewMode(50)" )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 46 - 46: rRrer
def rrreRRreRRRRRrre ( content , viewType ) :
 if content :
  xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , content )
  if 57 - 57: iiiIIii1IIi + iiiIIii1IIi
 xbmc . executebuiltin ( "Container.SetViewMode(true)" )
 if 56 - 56: Ii1I + IIII
def Ii1Ii1 ( ) :
 ii1IiI11I = [ ]
 RRreRrrrerereRre = sys . argv [ 2 ]
 if len ( RRreRrrrerereRre ) >= 2 :
  RRrerRRrr = sys . argv [ 2 ]
  rrerer = RRrerRRrr . replace ( '?' , '' )
  if ( RRrerRRrr [ len ( RRrerRRrr ) - 1 ] == '/' ) :
   RRrerRRrr = RRrerRRrr [ 0 : len ( RRrerRRrr ) - 2 ]
  Iiii1Ii = rrerer . split ( '&' )
  ii1IiI11I = { }
  for RRRreRRRrererr in range ( len ( Iiii1Ii ) ) :
   rrRRrrererrre = { }
   rrRRrrererrre = Iiii1Ii [ RRRreRRRrererr ] . split ( '=' )
   if ( len ( rrRRrrererrre ) ) == 2 :
    ii1IiI11I [ rrRRrrererrre [ 0 ] . lower ( ) ] = rrRRrrererrre [ 1 ]
 return ii1IiI11I
 if 40 - 40: rRrer - iII111i - iII111i - RRreRRreRreRre - RRreRRreRreRre . iIiiiI1IiI1I1
 if 57 - 57: I1Ii111 - iII111iiiii11
RRrerRRrr = Ii1Ii1 ( )
rrrreR = None
rRrRrerrereRRre = None
Ii1i1 = None
iI1i11 = None
IiIIiii11II1 = None
ii1I = None
if 68 - 68: RRrrRRr % I11i / rRrerrerrRre + rRrerrerrRre - rRrerrerrRre . RrrrererRrrerer
try :
 rrrreR = urllib . unquote_plus ( RRrerRRrr [ "url" ] )
except :
 pass
try :
 rRrRrerrereRRre = urllib . unquote_plus ( RRrerRRrr [ "name" ] )
except :
 pass
try :
 iI1i11 = urllib . unquote_plus ( RRrerRRrr [ "iconimage" ] )
except :
 pass
try :
 Ii1i1 = int ( RRrerRRrr [ "mode" ] )
except :
 pass
try :
 IiIIiii11II1 = urllib . unquote_plus ( RRrerRRrr [ "description" ] )
except :
 pass
 if 100 - 100: rRrer % IiIIi1I1Iiii
RRrerRRrr = Ii1Ii1 ( ) ; rrrreR = None ; rRrRrerrereRRre = None ; Ii1i1 = None ; RrRR = None ; iI1i11 = None
try : RrRR = urllib . unquote_plus ( RRrerRRrr [ "site" ] )
except : pass
try : rrrreR = urllib . unquote_plus ( RRrerRRrr [ "url" ] )
except : pass
try : rRrRrerrereRRre = urllib . unquote_plus ( RRrerRRrr [ "name" ] )
except : pass
try : Ii1i1 = int ( RRrerRRrr [ "mode" ] )
except : pass
try : iI1i11 = urllib . unquote_plus ( RRrerRRrr [ "iconimage" ] )
except : pass
try : ii1I = urllib . unquote_plus ( RRrerRRrr [ "channels" ] )
except : pass
if 1 - 1: I11i . RrreRrr
if Ii1i1 == None or len ( rrererrrrRrerR ) <> 19 or rrrreR == None or len ( rrrreR ) < 1 or Ii1i1 == 99 :
 IIi ( )
 if 74 - 74: RRreRRreRreRre + iII111iiiii11 / Ii1I / rRrer . I11i % Ii1I
elif Ii1i1 == 1 :
 Rrrrerrerrre ( rrrreR )
elif Ii1i1 == 2 :
 RrRRrere ( rrrreR )
elif Ii1i1 == 3 or Ii1i1 == 12 or Ii1i1 == 32 :
 rreRrRreRRrRreRrre ( rRrRrerrereRRre , rrrreR , iI1i11 )
elif Ii1i1 == 6 :
 I1ii1 ( rrrreR )
elif Ii1i1 == 7 :
 rrRrer ( rrrreR )
elif Ii1i1 == 9 :
 i1Ii1i1I11Iii ( rrrreR )
elif Ii1i1 == 11 :
 RR ( rrrreR )
elif Ii1i1 == 14 :
 iIII11Iiii1 ( rRrRrerrereRRre , rrrreR , iI1i11 )
elif Ii1i1 == 15 :
 iiiII ( rrrreR )
elif Ii1i1 == 16 :
 iiIiii1iI1i ( rRrRrerrereRRre , rrrreR , iI1i11 )
elif Ii1i1 == 20 :
 RrRRrere ( rrrreR )
elif Ii1i1 == 30 :
 Ii ( )
elif Ii1i1 == 31 :
 i11iIIi ( rrrreR , iI1i11 , rRrRrerrereRRre )
elif Ii1i1 == 33 :
 rrerrreRrerRrrrR ( rrrreR )
elif Ii1i1 == 34 :
 Iiii1 ( )
elif Ii1i1 == 40 :
 ReadUrl ( rrrreR )
elif Ii1i1 == 41 :
 common . DelFile ( RRrRreRrererre )
elif Ii1i1 == 45 :
 TV ( )
elif Ii1i1 == 50 :
 RRRrereR ( )
 sys . exit ( )
elif Ii1i1 == 58 :
 RreRr ( rrrreR )
elif Ii1i1 == 59 :
 RrRrererre ( rrrreR )
elif Ii1i1 == 60 or Ii1i1 == 46 :
 rRrRre ( rrrreR )
elif Ii1i1 == 61 :
 Iii1iiIi1II ( rrrreR )
elif Ii1i1 == 66 :
 VIDEOLINKS ( rRrRrerrereRRre , rrrreR , iI1i11 )
elif Ii1i1 == 68 :
 iIII1iiIi11 ( rRrRrerrereRRre , rrrreR , iI1i11 )
elif Ii1i1 == 75 :
 IiiIiI ( rrrreR )
elif Ii1i1 == 76 :
 RRre ( rrrreR )
elif Ii1i1 == 77 :
 i1I1i ( rrrreR )
elif Ii1i1 == 78 :
 IiIIII ( rrrreR )
elif Ii1i1 == 80 :
 RreRrre ( rrrreR )
elif Ii1i1 == 81 :
 i11i111IiI ( rRrRrerrereRRre , rrrreR )
elif Ii1i1 == 82 :
 RRRr ( rrrreR )
elif Ii1i1 == 83 :
 I1I11IiiI ( rRrRrerrereRRre , rrrreR )
elif Ii1i1 == 84 :
 rreRRreRreRRrerRre ( rRrRrerrereRRre , rrrreR )
elif Ii1i1 == 85 :
 IIIiI1ii1IIi ( rRrRrerrereRRre , rrrreR )
elif Ii1i1 == 86 :
 rrerrRreRRR ( rrrreR )
elif Ii1i1 == 87 :
 Rrrer ( rrrreR )
elif Ii1i1 == 88 :
 RrrrerRre ( rrrreR )
elif Ii1i1 == 98 :
 sys . exit ( )
elif Ii1i1 == 151 :
 rrerere ( rrrreR )
elif Ii1i1 == 152 :
 IIi1II ( rRrRrerrereRRre , rrrreR )
elif Ii1i1 == 153 :
 NEXTPAGE ( page )
elif Ii1i1 == 154 :
 rRrreRrereR ( )
elif Ii1i1 == 120 :
 RrrerrrreRrr ( rRrRrerrereRRre , rrrreR , iI1i11 )
elif Ii1i1 == 200 :
 RR ( rrrreR )
elif Ii1i1 == 210 :
 RRRR ( rrrreR )
elif Ii1i1 == 230 :
 I1111i ( rrrreR )
elif Ii1i1 == 240 :
 RRRRRr ( rRrRrerrereRRre , rrrreR , iI1i11 )
elif Ii1i1 == 250 :
 rreR ( )
elif Ii1i1 == 300 :
 rRrrereRrRreR ( )
elif Ii1i1 == 310 :
 rrerRRRRre ( rRrRrerrereRRre , rrrreR , IiIIiii11II1 )
elif Ii1i1 == 320 :
 i1IiiiiIi1I ( rRrRrerrereRRre , rrrreR , iI1i11 )
elif Ii1i1 == 400 :
 RrRrRrrererre ( )
elif Ii1i1 == 520 :
 Ii1iIiII1Ii ( rrrreR )
elif Ii1i1 == 600 :
 rRRrr ( rrrreR )
elif Ii1i1 == 610 :
 rRrrRre ( rrrreR )
elif Ii1i1 == 700 :
 IIiI1i ( rrrreR )
elif Ii1i1 == 710 :
 IIiI11i11 ( rrrreR )
elif Ii1i1 == 720 :
 iIrrrrerr ( )
elif Ii1i1 == 721 :
 I11iiii ( rRrRrerrereRRre , rrrreR , iI1i11 )
elif Ii1i1 == 745 :
 iiIII1i ( rrrreR )
elif Ii1i1 == 746 :
 i111I1iiIiII ( )
elif Ii1i1 == 750 :
 iiI1I1ii ( rRrRrerrereRRre , rrrreR , iI1i11 )
elif Ii1i1 == 760 :
 iIIiII ( )
elif Ii1i1 == 761 :
 I1IIII1i ( rRrRrerrereRRre , rrrreR , iI1i11 )
elif Ii1i1 == 762 :
 RreRi1I1I ( rRrRrerrereRRre , rrrreR , iI1i11 )
elif Ii1i1 == 763 :
 iiRrerrerRRRrRr ( rRrRrerrereRRre , rrrreR , iI1i11 )
elif Ii1i1 == 770 :
 rRRrereR ( )
elif Ii1i1 == 771 :
 i1RRrR ( rRrRrerrereRRre , rrrreR , iI1i11 )
elif Ii1i1 == 772 :
 RrRreRRRRrreR ( rRrRrerrereRRre , rrrreR , iI1i11 )
elif Ii1i1 == 773 :
 RreRreRrrrrer ( rRrRrerrereRRre , rrrreR , iI1i11 )
 if 34 - 34: I1IiiI . IIiIiII11i
elif Ii1i1 == 1000 :
 rrrrRre ( )
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
